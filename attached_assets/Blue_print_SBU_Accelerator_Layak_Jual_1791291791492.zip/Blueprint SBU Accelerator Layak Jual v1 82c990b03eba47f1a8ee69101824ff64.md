# Blueprint SBU Accelerator Layak Jual v1

> 🎯 Tujuan: menjadikan SBU Accelerator **layak jual** — dari "catatan persiapan" menjadi **workbench kesiapan SBU** yang bisa dibayar kontraktor & konsultan perizinan. Posisi tetap: **deklaratif, independen dari LPJK/PU/LSBU**, tidak menerbitkan atau menjamin SBU.
> 

## 1. Posisi & janji produk

- **Janji:** "Tahu persis apa yang kurang untuk SBU Anda, dalam 30 menit — lalu selesaikan dengan rencana aksi."
- **Bukan:** LSBU atau penjamin kelulusan verifikasi. Aplikasi tetap alat mandiri; pendampingan berbayar dijalankan terpisah lewat Klinik Konsultasi & Workroom Gustafta OS (§14).
- **Pembeda:** katalog subklasifikasi + matriks syarat per kualifikasi, kalkulator kesiapan, modul tenaga kerja/SKK, ekspor PDF siap rapat, multi-klien untuk konsultan.

## 2. Persona & paket

| Persona | Masalah | Paket |
| --- | --- | --- |
| Kontraktor/konsultan kecil | Tidak tahu syarat subklasifikasi & kualifikasi | **Mandiri** – 1 badan usaha, 3 kasus |
| Kontraktor menengah/besar | Banyak subklasifikasi, transisi PP 28/2025 | **Bisnis** – 1 BU, kasus tak terbatas, pengingat, AI per temuan |
| Konsultan perizinan / asosiasi | Mengelola banyak klien | **Konsultan** – multi-klien, white-label PDF, tim |
| Add-on | Butuh kepastian | **Telaah Ahli** per kasus (manusia) |

Harga awal (uji pasar, bisa diubah): Mandiri Rp99rb/bln · Bisnis Rp249rb/bln · Konsultan Rp749rb/bln (10 klien) · Telaah Ahli mulai Rp500rb/kasus. Bundel peluncuran: **Ebook + Toolkit + Tutor AI (Rp249rb) + 3 bulan Mandiri**. Pembayaran via **Scalev**.

## 3. Modul versi 1 (wajib sebelum dijual)

### M1 · Katalog Subklasifikasi & Matriks Syarat

- Kualifikasi disimpan sebagai **data master menurut jenis usaha**, bukan satu daftar yang berlaku sama untuk seluruh usaha. Pada skema terlampir: **Pekerjaan Konstruksi** kualifikasi kecil memiliki subkualifikasi **K1/K2/K3**, dengan **M** (menengah) dan **B** (besar); tabel **Konsultansi Konstruksi BUJKN** menggunakan **K/M/B**; **Pekerjaan Konstruksi Terintegrasi** berkualifikasi **B**. Ketersediaan pada tiap subklasifikasi dan bentuk BUJK mengikuti Lampiran Kepdirjen 281/KPTS/DK/2026 bagian 2.1.3–2.1.5, dengan status telaah dan pemicu operasional sebagaimana §11.
- Tabel referensi: klasifikasi → subklasifikasi → KBLI → kualifikasi → syarat (penjualan tahunan, kemampuan keuangan, PJBU/PJTBU/PJSKBU + jenjang SKK, peralatan, SMAP/SMM).
- Setiap baris wajib punya `sumber` (peraturan + pasal/lampiran), `berlaku_sejak`, `status_verifikasi` (draf / ditelaah ahli / final).
- Jenis permohonan diperluas: Baru, Perpanjangan, **Perubahan Data, Penambahan Subklasifikasi, Kenaikan/Penurunan Kualifikasi, Konversi/Transisi**.

### M2 · Kalkulator Kesiapan

- Skor 0–100 per dimensi (legalitas, keuangan, penjualan, tenaga kerja, peralatan, SMAP/SMM) + status "Siap / Hampir / Belum".
- Setiap kekurangan → otomatis menjadi **item rencana aksi** (pemilik, tenggat, bukti yang dibutuhkan).

### M3 · Tenaga Kerja & SKK

- Daftar personel: nama, peran (PJBU/PJTBU/PJSKBU/tenaga ahli), SKK (subklasifikasi, jenjang, nomor, masa berlaku), status penugasan.
- Cek otomatis: jenjang cocok dengan kualifikasi, satu orang tidak dipakai ganda, SKK kedaluwarsa < 90 hari → peringatan. Tautan ke **Exum SKK** untuk yang belum punya.

### M4 · Dokumen & Bukti

- Unggah bukti per kategori (via **Ruang Simpan** API; fallback penyimpanan lokal), masa berlaku dokumen, status "ada / kurang / kedaluwarsa".
- Profil perusahaan diambil dari `GET /api/v1/ruang-simpan/company-profile`.

### M5 · Ekspor PDF

- "Laporan Kesiapan SBU": ringkasan skor, matriks syarat vs kondisi, daftar kekurangan, rencana aksi, disclaimer independensi, sumber regulasi. White-label untuk paket Konsultan.

### M6 · Ruang Kerja Multi-Klien

- Organisasi Clerk = kantor konsultan; klien = badan usaha di bawahnya; peran Pemilik/Staf/Klien (klien hanya lihat & unggah).

### M7 · Langganan & Kuota

- Webhook Scalev → tabel `subscriptions`; gating fitur per paket; halaman harga & upgrade.

## 4. Modul versi 1.1–1.2

- **Pengingat**: masa berlaku SBU, SKK, sertifikat SMAP/ISO, laporan LKUT (email/WhatsApp).
- **AI per temuan**: tombol "Jelaskan & sarankan" pada setiap kekurangan, menjawab hanya dari katalog + sumber terverifikasi, selalu menampilkan sumber.
- **Telaah Ahli**: antrean kasus untuk ahli manusia, catatan + tanda "ditelaah".
- **Integrasi ekosistem**: Compliance Hub (SMAP/PUB), LKUT, Exum SKK, Radar Legalitas (perubahan regulasi → tandai kasus terdampak).

## 5. Model data inti

| Tabel | Kolom utama |
| --- | --- |
| `orgs` / `clients` | org_id, nama, tipe (kontraktor/konsultan/kantor konsultan), paket |
| `cases` | client_id, jenis_permohonan, subklasifikasi[], kualifikasi, target_tanggal, skor, status |
| `catalog_subclass` | kode, nama, klasifikasi, kbli[], jenis_usaha |
| `requirements` | subclass_kode, kualifikasi, dimensi, aturan (JSON), sumber, berlaku_sejak, status_verifikasi |
| `personnel` | client_id, nama, peran, skk_subklas, jenjang, no_skk, berlaku_sampai |
| `evidence` | case_id, kategori, file_ref (Ruang Simpan), berlaku_sampai, status |
| `action_items` | case_id, requirement_id, judul, pemilik, tenggat, status |
| `subscriptions` | org_id, paket, scalev_order_id, aktif_sampai |
| `reg_changes` | peraturan, ringkasan, tanggal, requirement_ids terdampak |

## 6. Agen (Hermes sebagai orkestrator)

| Agen | Tugas | Gerbang manusia |
| --- | --- | --- |
| **Kurator Regulasi** | Memantau JDIH PU/LPJK, mengusulkan perubahan `requirements` beserta sumber pasal | Wajib disetujui ahli sebelum `final` |
| **Penilai Kasus** | Menghitung skor, menyusun rencana aksi | – (deterministik dari aturan) |
| **Asisten Temuan** | Menjelaskan kekurangan dengan sitasi | Tidak boleh menjawab di luar katalog |
| **Penyusun Laporan** | Menyusun PDF | – |
| **Pengingat** | Menjadwalkan notifikasi | – |

Hermes menyimpan *skill memory* per agen (pola temuan umum, template jawaban) — tetapi **aturan syarat hanya berasal dari tabel** `requirements` **final**, bukan dari memori model.

## 7. Gerbang layak jual (checklist)

- [ ]  Katalog minimal 20 subklasifikasi paling laku, semua baris berstatus "ditelaah ahli"
- [ ]  Kalkulator diuji pada 10 kasus nyata, selisih dengan penilaian ahli ≤ 10%
- [ ]  Ekspor PDF + disclaimer independensi
- [ ]  Pembayaran Scalev end-to-end + gating paket
- [ ]  Multi-klien teruji dengan 2 kantor konsultan
- [ ]  Halaman harga, syarat layanan, kebijakan privasi (UU PDP)
- [ ]  5 pengguna beta membayar

## 8. Roadmap 8 minggu

| Minggu | Hasil |
| --- | --- |
| 1–2 | M1 katalog + matriks (data awal & UI admin), jenis permohonan diperluas |
| 3 | M2 kalkulator + rencana aksi otomatis |
| 4 | M3 tenaga kerja/SKK |
| 5 | M4 unggah via Ruang Simpan + M5 PDF |
| 6 | M6 multi-klien + M7 Scalev |
| 7 | Beta tertutup (kontraktor + konsultan) |
| 8 | Peluncuran bundel ebook + aplikasi |

## 9. Pemetaan Ebook ↔ Aplikasi

| Bab ebook | Modul aplikasi |
| --- | --- |
| Bab 1–2 (pahami regulasi & transisi) | Pusat Regulasi + verifikasi transisi |
| Bab 3 (evaluasi/gap 5 dimensi) | M2 Kalkulator Kesiapan |
| Bab 4–5 (SKK & tenaga kerja) | M3 Tenaga Kerja & SKK |
| Bab 6 (dokumen/templat) | M4 Dokumen + templat unduh |
| Bab 7–8 (SMAP/SMM, tender) | Tautan Compliance Hub, pengingat |
| Bab 10 (roadmap 90 hari) | Rencana aksi + pengingat |

Setiap kotak "Aksi Sekarang" di ebook diberi QR/tautan ke modul terkait.

## 10. Prompt Replit

Paket prompt lengkap (Prompt 0–14, berurutan, dengan kriteria terima dan daftar Secrets) ada di [Paket Prompt Replit — SBU Accelerator v1](https://app.notion.com/p/Paket-Prompt-Replit-SBU-Accelerator-v1-e2ec567f23384901b857b999635b6c0c?pvs=21). Prompt versi awal di halaman ini sudah digantikan.

## 11. Catatan verifikasi

Isi katalog dan ambang syarat **wajib** diambil dari teks resmi PP 28/2025, Permen PU 6/2025, dan standar skema sertifikasi yang telah ditelaah. Berkas primer, panduan, praktik baik, serta paket teks/metadata tersedia di [Pustaka Sumber Regulasi — SBU Accelerator](https://app.notion.com/p/Pustaka-Sumber-Regulasi-SBU-Accelerator-f567161131b741c9972c0a4f435503a4?pvs=21). Identitas **Kepdirjen Bina Konstruksi 281/KPTS/DK/2026** dan tanggal penetapannya telah dicocokkan dari salinan terlampir; status hukum terkini dan pemberlakuan operasional tetap perlu dikonfirmasi. Korpus dan calon persyaratan masih draf, belum diimpor atau diaktifkan pada aplikasi.

Catatan yang wajib ditelaah sebelum mengaktifkan katalog/matriks:

- **Jenis usaha menentukan kualifikasi:** Lampiran Kepdirjen bagian 2.1.3 butir 2 menyebut K1/K2/K3 untuk Pekerjaan Konstruksi; tabel konsultansi pada bagian 2.1.5 menggunakan K/M/B untuk BUJKN. Model kualifikasi tidak boleh menyamaratakan K1/K2/K3 ke konsultansi.
- **Pemicu transisi:** Permen PU 6/2025 Pasal 20 ayat (2) mengatur surat dimulainya penyelenggaraan melalui SIJK; Pasal 21 ayat (2) mengaitkan batas konversi dengan 6 bulan sejak surat tersebut. Jangan menetapkan tenggat kalender hanya dari tanggal Kepdirjen atau sosialisasi.
- **Provenance:** pisahkan tahun peraturan, tahun paparan, edisi KBLI, sumber primer dan praktik lembaga; setiap syarat harus memiliki pasal/lampiran, halaman PDF, versi dan persetujuan penelaah.

Jangan memasukkan angka dari ebook sebelum ebook dikoreksi; lihat [Review & Perbaikan Ebook "SBU & SKK Tanpa Bingung"](https://app.notion.com/p/Review-Perbaikan-Ebook-SBU-SKK-Tanpa-Bingung-7a8000ebc0ca4c438cf388cf7cebc271?pvs=21).

## 12. Peran LSBU & posisi aplikasi

**Dasar:** Undang-Undang Jasa Konstruksi (UU 2/2017 beserta perubahannya dalam UU Cipta Kerja) mengamanatkan sertifikasi badan usaha jasa konstruksi, yang dilaksanakan melalui **Lembaga Sertifikasi Badan Usaha (LSBU)**. Ketentuan pelaksananya diatur dalam PP 28/2025 dan Permen PU 6/2025 (pasal rinci perlu dikonfirmasi dari teks resmi sebelum dikutip di aplikasi).

**Peran LSBU** (ringkas, untuk Mode Belajar):

- Menerima permohonan sertifikasi badan usaha (baru, perpanjangan, perubahan).
- Verifikasi & validasi dokumen persyaratan (legalitas, penjualan/pengalaman, keuangan, tenaga kerja, peralatan, sistem manajemen).
- Penilaian kesesuaian terhadap klasifikasi, subklasifikasi, dan kualifikasi.
- Penerbitan SBU melalui sistem yang ditetapkan, serta pengawasan/penilaian ulang sesuai ketentuan.

**Posisi SBU Accelerator terhadap LSBU:**

| Aspek | LSBU | SBU Accelerator |
| --- | --- | --- |
| Status | Lembaga yang diamanatkan UU | Alat bantu swasta, independen |
| Keputusan | Menilai & menerbitkan SBU | Tidak menilai resmi, tidak menerbitkan |
| Output | SBU | Skor kesiapan, rencana aksi, **Paket Siap Ajukan** |
| Biaya sertifikasi | Ditetapkan sesuai ketentuan LSBU | Tidak menarik biaya sertifikasi |

**Fitur terkait LSBU (M10):**

1. **Direktori LSBU** — diisi admin dari sumber resmi (nama, jenis usaha yang dilayani, status lisensi, kontak resmi, tanggal verifikasi data).
2. **Alur Sertifikasi** — linimasa interaktif: OSS/NIB → persiapan (aplikasi) → pengajuan ke LSBU → verifikasi → penerbitan → masa berlaku & perpanjangan.
3. **Paket Siap Ajukan** — ekspor ZIP berisi dokumen bernama baku per kategori + daftar isi + Laporan Kesiapan, disusun mengikuti struktur persyaratan.
4. **Pelacak status pengajuan** — pengguna mencatat sendiri status di LSBU (diajukan, perbaikan, terbit) dan permintaan perbaikan dari LSBU → otomatis jadi rencana aksi.
5. **Opsi kemitraan B2B** (nanti): LSBU/asosiasi dapat memakai aplikasi sebagai alat pra-pemeriksaan bagi anggotanya, dengan persetujuan pengguna untuk berbagi data, dan tanpa mengubah independensi penilaian.

## 13. Fitur tambahan v1.2

- **M8 · Tutor Regulasi SBU** — asisten berbasis teks resmi (PP 28/2025, Permen PU 6/2025, Kepdirjen Bina Konstruksi 281/2026, UU Jasa Konstruksi & regulasi terkait), mode Tanya / Belajar / Bandingkan / Kasus, selalu mengutip pasal.
- **M9 · Pustaka Kasus & Solusi** — tiga pustaka: **SBU, SKK, dan Perizinan Usaha**, masing-masing 50 skenario awal untuk permohonan baru (20), perpanjangan/pemeriksaan keberlanjutan (15), dan perubahan data (15). Untuk kontraktor, konsultan, dan tenaga kerja konstruksi: diagnosis, langkah penanganan, bukti, peran lembaga, hasil yang diharapkan, serta pelajaran studi banding. Asal **skenario** dibedakan dari **kasus nyata bersumber**; hasil aktual tidak dikarang. Data awal Draf, publikasi aplikasi hanya setelah Final dan telaah rujukan. Sumber: [Pustaka Kasus SBU, SKK & Perizinan Usaha](https://app.notion.com/p/Pustaka-Kasus-SBU-SKK-Perizinan-Usaha-0269ad9eacd4455fa0d143192887ff70?pvs=21); implementasi mengikuti Prompt 16 dan tidak berarti sudah terpasang di Replit.
- **M10 · Modul LSBU** — lihat §12.
Prompt Replit: Prompt 15–17 di [Paket Prompt Replit — SBU Accelerator v1](https://app.notion.com/p/Paket-Prompt-Replit-SBU-Accelerator-v1-e2ec567f23384901b857b999635b6c0c?pvs=21).

## 14. Integrasi Gustafta OS: Klinik Konsultasi → Workroom (M11 · Layanan Pendampingan)

Gustafta OS sudah punya pilar yang dibutuhkan, jadi **SBU Accelerator tidak membangun ruang kerja pendampingan sendiri**.

| Pilar Gustafta OS | Peran untuk SBU/SKK |
| --- | --- |
| 01 · Coach | **SBU Coach** (Tutor Regulasi, M8), berdampingan dengan SKK Coach yang sudah ada |
| 02 · Claw | Agen (Kurator Regulasi, Penilai Kasus, Penyusun Dokumen) yang bekerja di dalam Workroom |
| 03 · Workroom | Ruang kerja pendampingan bertahap + gerbang persetujuan manusia ◆ |
| 04 · Academy | Mode Belajar, kuis, Pustaka Kasus (M9) |
| 05 · Competency & Monetization | Mitra pendamping (kantor konsultan), komisi, rating |
| Klinik Konsultasi | Pintu masuk: loket SBU/SKK, triase AI, eskalasi ke operator manusia |

**Alur pengguna**

1. **SBU Accelerator** — pengguna menilai sendiri (skor, temuan, Paket Siap Ajukan).
2. **Klinik → loket SBU–SKK** — tombol "Konsultasikan" dari temuan/paket terkunci membuka loket dengan konteks kasus. AI menjawab dulu; kasus khusus diteruskan ke operator.
3. **Workroom** — bila pengguna memilih paket pendampingan, Workroom dibuat dari templat **"Persiapan SBU"** atau **"Persiapan SKK"**, terisi otomatis dari kasus.
4. **Hasil kembali** ke SBU Accelerator: rencana aksi diperbarui, badge "Didampingi Workroom", catatan ahli masuk Laporan PDF, lalu Paket Siap Ajukan → pengajuan ke LSBU (SBU) atau LSP (SKK) oleh pengguna/kuasanya.

**Templat Workroom "Persiapan SBU"** (tahap & gerbang ◆)

| Tahap | Dikerjakan | Gerbang ◆ |
| --- | --- | --- |
| 1. Intake | Impor kasus, skor, dokumen Ruang Simpan; persetujuan berbagi data | ◆ Klien setuju lingkup & biaya |
| 2. Diagnosis | Agen menganalisis kekurangan; ahli memvalidasi | ◆ Ahli menyetujui daftar kekurangan |
| 3. Pemenuhan | Klien unggah dokumen; agen menyusun draf surat/rekap | ◆ Klien mengonfirmasi kebenaran data |
| 4. QA | Cek silang syarat vs bukti, hitung ulang skor | ◆ Ahli menyatakan "siap ajukan" |
| 5. Pengajuan | Paket Siap Ajukan; pengajuan oleh klien/kuasa ke LSBU | ◆ Klien menyetujui pengajuan |
| 6. Pascapengajuan | Tindak lanjut permintaan perbaikan LSBU; catat SBU terbit | – |

Templat **"Persiapan SKK"**: Intake → Pemetaan jenjang & LSP → Portofolio pengalaman → Persiapan uji → Pengajuan ke LSP oleh peserta → Pencatatan SKK.

**Audit Workroom saat ini (domain SBU) → yang perlu ditambah**

| Area | Kondisi sekarang | Kurang / perbaikan |
| --- | --- | --- |
| Form buat Workroom | Field generik tender (instansi, pagu HPS) | Field per domain. SBU: badan usaha, jenis usaha (kontraktor/konsultan), jenis permohonan, subklasifikasi (dari katalog), kualifikasi target, target tanggal, tautan kasus SBU Accelerator |
| Label kualifikasi | "Gedung · K2" | Format K2 sudah benar (kualifikasi K1/K2/K3/M/B sesuai Permen PU 6/2025 & Kepdirjen 281/2026). Tambahkan kode subklasifikasi dan ambil kualifikasi dari data master |
| Urutan tahap | Pengajuan ke LSBU **sebelum** Review & Gerbang ◆ | Gerbang ◆ harus **sebelum** pengajuan. Tahap: Intake → Identifikasi subklasifikasi → Cek persyaratan → Pemenuhan berkas → QA & Gerbang ◆ → Pengajuan ke LSBU → Tindak lanjut LSBU → Terbit & Arsip |
| Tahapan | Hanya penanda tahap aktif (klik manual) | Checklist tugas per tahap, PIC, tenggat, syarat selesai tahap; tahap maju otomatis bila syarat & gerbang terpenuhi |
| Analisis AI | Satu tombol, dasar "UU Jasa Konstruksi & OSS-RBA" | Hasil terstruktur: skor per dimensi, daftar kekurangan, sitasi pasal (PP 28/2025, Permen PU 6/2025, Kepdirjen), label indikatif; riwayat analisis; tombol "jadikan tugas" |
| Gerbang ◆ | Teks bebas | Gerbang baku per tahap, penyetuju berperan (klien/ahli), status setuju/tolak + alasan, tidak bisa dilewati agen |
| Dokumen | Belum ada | Lampiran per syarat dari Ruang Simpan, status ada/kurang/kedaluwarsa, versi, draf dokumen buatan agen berlabel DRAF |
| Personel | Belum ada | Daftar PJBU/PJTBU/PJSKBU & SKK + validasi jenjang & masa berlaku (ditarik dari SBU Accelerator) |
| Kolaborasi | Jurnal catatan | Anggota & peran (klien, pendamping, operator, agen), komentar per tugas, mention, notifikasi |
| Pengajuan LSBU | Belum ada | Catat LSBU tujuan, nomor permohonan, status, permintaan perbaikan → tugas otomatis, nomor & masa berlaku SBU |
| Layanan & batas | Belum ada | Tingkat layanan & order Scalev, teks batas layanan, deteksi permintaan terlarang |
| Integrasi | Berdiri sendiri | Sinkron dua arah dengan SBU Accelerator (handoff & webhook), Klinik (eskalasi), Pustaka Kasus |
| Jejak | Belum ada | Audit log, ekspor ringkasan Workroom (PDF), arsip setelah selesai |

Prompt penyempurnaan: Prompt 19A.

**Tingkat layanan (dijual via Scalev)**

| Tingkat | Isi |
| --- | --- |
| Telaah Ahli | Pemeriksaan kasus + catatan (tanpa Workroom penuh) |
| Pendampingan | Workroom, sesi konsultasi, ahli memeriksa dokumen buatan klien |
| Penyusunan Dokumen | Tim/agen menyusun surat & rekap dari data klien; klien tetap menandatangani & mengajukan |
| Pendampingan SKK | Portofolio, pemilihan jenjang/LSP, persiapan uji |

**Batas layanan (wajib di perjanjian & UI)**

- Tidak menjamin SBU/SKK terbit; penilaian oleh LSBU/LSP.
- Dilarang: menyediakan/menyewakan tenaga ahli ("pinjam nama"), joki uji kompetensi, merekayasa pengalaman/keuangan, bagi hasil dengan LSBU/LSP.
- Biaya resmi LSBU/LSP dipisahkan dari jasa pendampingan.
- Akses pendamping ke data hanya selama Workroom aktif, dengan persetujuan klien dan tercatat.

Prompt: Prompt 18 (SBU Accelerator) dan Prompt 19 (Gustafta OS / Workroom) di [Paket Prompt Replit — SBU Accelerator v1](https://app.notion.com/p/Paket-Prompt-Replit-SBU-Accelerator-v1-e2ec567f23384901b857b999635b6c0c?pvs=21). Prompt 15 (Tutor) dapat dibangun sebagai **SBU Coach** di pilar Coach agar dipakai bersama aplikasi lain.

[Paket Prompt Replit — SBU Accelerator v1](https://app.notion.com/p/Paket-Prompt-Replit-SBU-Accelerator-v1-e2ec567f23384901b857b999635b6c0c?pvs=21)

[Pustaka Kasus SBU, SKK & Perizinan Usaha](https://app.notion.com/p/Pustaka-Kasus-SBU-SKK-Perizinan-Usaha-0269ad9eacd4455fa0d143192887ff70?pvs=21)
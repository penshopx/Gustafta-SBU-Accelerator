# Paket Prompt Replit — SBU Accelerator v1

> 🧩 Paket prompt Replit untuk menjalankan **Blueprint SBU Accelerator Layak Jual v1**. Tempel **satu prompt per sesi**, sesuai urutan. Uji kriteria terima dulu sebelum lanjut ke prompt berikutnya. Semua prompt berbahasa Indonesia; label UI tetap berbahasa Indonesia.
> 

## Cara pakai

1. Tempel **Prompt 0** sekali di awal (atau simpan di `replit.md` / instruksi Agent).
2. Jalankan Prompt 1 → 19 berurutan (Prompt 19 dijalankan di proyek Replit Gustafta OS, bukan SBU Accelerator). Setiap prompt sudah memuat **kriteria terima**. Jika gagal, balas: "Kriteria X belum terpenuhi, perbaiki tanpa mengubah fitur lain."
3. Commit / checkpoint setelah setiap prompt lulus.
4. **Jangan** isi angka ambang syarat dari ingatan AI. Data syarat diisi admin dari teks resmi (status `draf` → `ditelaah` → `final`).

| # | Prompt | Fase | Paket |
| --- | --- | --- | --- |
| 0 | Konteks & aturan main | Fondasi | – |
| 1 | Audit kode & fondasi data | Fondasi | – |
| 2 | Katalog subklasifikasi & matriks syarat | v1 | Semua |
| 3 | Kasus diperluas (jenis permohonan, multi-subklasifikasi) | v1 | Semua |
| 4 | Tenaga kerja & SKK | v1 | Semua |
| 5 | Bukti & dokumen (Ruang Simpan) | v1 | Semua |
| 6 | Kalkulator kesiapan & rencana aksi | v1 | Semua |
| 7 | Laporan PDF | v1 | Semua (white-label: Konsultan) |
| 8 | Multi-klien & peran | v1 | Konsultan |
| 9 | Langganan Scalev & gating | v1 | – |
| 10 | Halaman publik, legal, onboarding | v1 | – |
| 11 | Pengingat masa berlaku | v1.1 | Bisnis, Konsultan |
| 12 | AI per temuan (terbatas sumber) | v1.1 | Bisnis, Konsultan |
| 13 | Telaah Ahli & Radar Regulasi | v1.2 | Add-on |
| 14 | Pengerasan, uji & siap rilis | Rilis | – |
| 15 | Tutor Regulasi SBU (RAG bersitasi pasal) | v1.2 | Gratis terbatas → penuh di Bisnis/Konsultan |
| 16 | Tiga Pustaka Kasus & Studi Banding (SBU, SKK, Perizinan) | v1.3 | Semua |
| 17 | Modul LSBU (peran, direktori, Paket Siap Ajukan, pelacak) | v1.2 | Semua |
| 18 | Jembatan ke Klinik & Workroom (sisi SBU Accelerator) | v1.2 | Layanan pendampingan |
| 19 | Templat Workroom Persiapan SBU/SKK (sisi Gustafta OS) | v1.2 | Layanan pendampingan |
| 19A | Penyempurnaan Workroom domain SBU/SKK (dari kondisi saat ini) | v1.2 – jalankan lebih dulu dari 19 | Layanan pendampingan |

---

## Prompt 0 — Konteks & aturan main

```
Kamu bekerja pada aplikasi "Gustafta SBU Accelerator" (https://gustafta-sbu-accelerator.replit.app), bagian dari ekosistem Gustafta (gustafta.my.id).

POSISI PRODUK (wajib dijaga di UI, kode, dan teks):
- Workbench persiapan mandiri SBU (Sertifikat Badan Usaha) jasa konstruksi untuk badan usaha kontraktor & konsultan, serta kantor konsultan perizinan.
- Deklaratif dan independen: TIDAK berafiliasi dengan Kementerian PU, LPJK, atau LSBU; TIDAK menerbitkan, memverifikasi resmi, atau menjamin SBU.
- Sertifikasi badan usaha dilaksanakan oleh LSBU (Lembaga Sertifikasi Badan Usaha) sesuai amanat Undang-Undang Jasa Konstruksi; SKK tenaga kerja oleh LSP. Aplikasi hanya membantu persiapan menuju pengajuan ke LSBU.
- Rujukan regulasi: PP 28/2025, Permen PU 6/2025, keputusan Dirjen Bina Konstruksi yang berlaku. Angka syarat hanya boleh berasal dari tabel requirements yang diisi admin, bukan di-hardcode.
- Kualifikasi SBU yang berlaku (Permen PU 6/2025 & Kepdirjen Bina Konstruksi 281/2026): K1, K2, K3 (golongan kecil), M (menengah), B (besar). Daftar kualifikasi disimpan sebagai data master (tabel qualifications), bukan hardcode.

KONDISI SAAT INI (pertahankan, jangan dirusak):
- Auth Clerk (organisasi tersedia), endpoint /api/me.
- Rute: /dashboard, /cases, /cases/:id, /company-profile, /regulations, /settings, /onboarding, /transition-verifications.
- API: /api/cases, /api/cases/:id/evidence, /api/cases/:id/assessment, /api/regulations, /api/transition-verifications, /api/ruang-simpan/company-profile.
- Kasus: nama badan usaha, jenis permohonan, kualifikasi (Kecil/Menengah/Besar — skema lama di aplikasi, wajib dimigrasikan ke K1/K2/K3/M/B), klasifikasi, masa berlaku; status Draf / Dalam peninjauan / Persiapan selesai; 9 kategori bukti; rencana aksi; peran pengguna Kontraktor/Konsultan/Profesional/Asosiasi.

ATURAN KERJA:
1. Sebelum mengubah, baca struktur repo dan jelaskan singkat rencanamu. Ikuti stack, ORM, dan gaya kode yang sudah ada.
2. Perubahan skema lewat migrasi yang aman (tidak menghapus data). Data lama harus tetap tampil.
3. Semua endpoint baru wajib cek auth + kepemilikan data (org/klien). Tidak ada data lintas organisasi yang bocor.
4. Validasi input di server (zod atau setara). Pesan error dalam bahasa Indonesia.
5. Tidak menyimpan rahasia di kode; gunakan Secrets Replit.
6. Data pribadi (NIK, dll.) disimpan seminimal mungkin; NIK hanya hash/4 digit terakhir (UU PDP).
7. Selesai setiap tugas: jalankan aplikasi, uji kriteria terima, laporkan file yang diubah dan cara mengujinya.
8. Jangan mengubah fitur di luar lingkup prompt.
Balas "SIAP" lalu tunggu prompt berikutnya.
```

## Prompt 1 — Audit kode & fondasi data

```
Tugas: audit dan siapkan fondasi.
1. Petakan stack (frontend, backend, database, ORM, storage) dan tulis ringkasannya di replit.md bagian "Arsitektur".
2. Tambahkan tabel/kolom fondasi lewat migrasi:
   - clients (id, org_id, nama_badan_usaha, jenis_usaha: kontraktor|konsultan, npwp_masked, nib, alamat, created_at). Untuk setiap pemilik data saat ini, buat 1 client default dan isi client_id pada cases yang ada.
   - audit_logs (id, org_id, user_id, aksi, entitas, entitas_id, data_ringkas jsonb, created_at).
   - app_settings (key, value jsonb) untuk konfigurasi seperti teks disclaimer.
3. Buat helper server getContext(req) → { userId, orgId, role, clientIds yang boleh diakses }. Gunakan di semua endpoint kasus.
4. Tambahkan komponen <Disclaimer/> berisi teks: "SBU Accelerator adalah alat bantu persiapan mandiri dan tidak berafiliasi dengan Kementerian PU, LPJK, maupun LSBU. Aplikasi ini tidak menerbitkan atau menjamin SBU." Tampilkan di footer semua halaman.
Kriteria terima:
- Kasus lama tetap tampil dan memiliki client_id.
- Pengguna A tidak bisa membuka /api/cases/:id milik pengguna B (uji manual, hasil 403/404).
- Disclaimer tampil di semua halaman.
```

## Prompt 2 — Katalog subklasifikasi & matriks syarat

```
Tugas: modul Katalog + Matriks Syarat (data referensi yang dikelola admin).
Skema (migrasi):
- catalog_subclass: kode (PK, teks), nama, klasifikasi, jenis_usaha (kontraktor|konsultan), kbli text[], aktif bool, catatan.
- qualifications (data master): kode (k1|k2|k3|m|b), nama (K1, K2, K3, M, B), golongan (kecil|menengah|besar), urutan (1–5), sumber, aktif. Seed: K1, K2, K3 = kecil; M = menengah; B = besar.
- requirements: id, subclass_kode (nullable = berlaku umum), jenis_usaha, kualifikasi (FK qualifications.kode: k1|k2|k3|m|b), dimensi (legalitas|penjualan|keuangan|tenaga_kerja|peralatan|smap_smm), kode_syarat, judul, deskripsi, tipe_aturan (dokumen_ada|angka_minimal|jumlah_personel|jenjang_skk|boolean), parameter jsonb (mis. {"min": 0, "satuan": "Rp"} atau {"peran":"pjtbu","jenjang_min":"…","jumlah":1}), bukti_dibutuhkan text[], bobot int default 1, sumber (wajib, mis. "Permen PU 6/2025 Lampiran …"), berlaku_sejak date, berlaku_sampai date null, status_verifikasi (draf|ditelaah|final), ditelaah_oleh, ditelaah_pada, versi int.
- requirement_history: salinan baris lama setiap kali requirements diubah.
Fitur:
1. Peran admin aplikasi (daftar email admin di Secret ADMIN_EMAILS). Halaman /admin/catalog dan /admin/requirements: tabel, filter (jenis usaha, kualifikasi, dimensi, status), CRUD, impor/ekspor CSV, tombol "Tandai ditelaah" dan "Finalkan" (hanya admin).
2. Halaman pengguna /catalog: cari subklasifikasi (kode/nama/KBLI), lihat matriks syarat per kualifikasi dalam tabel: dimensi × K1/K2/K3/M/B (kolom dikelompokkan per golongan kecil/menengah/besar). Setiap syarat menampilkan sumber dan badge status: draf = "Indikatif – belum ditelaah", ditelaah = "Ditelaah ahli", final = "Final".
3. Seed: buat CSV contoh di /seed/catalog_contoh.csv dengan 5 subklasifikasi DUMMY berlabel "CONTOH – ganti dengan data resmi" dan syarat berstatus draf dengan sumber "PERLU DIISI". Jangan mengarang angka ambang resmi.
Kriteria terima:
- Admin bisa impor CSV dan finalkan syarat; non-admin mendapat 403 di /admin/*.
- Mengubah syarat final membuat baris requirement_history dan menaikkan versi.
- /catalog menampilkan matriks lengkap dengan sumber dan badge.
```

## Prompt 3 — Kasus diperluas

```
Tugas: perluas model kasus agar memakai katalog.
1. Migrasi cases: tambah client_id (wajib), jenis_usaha, jenis_permohonan (enum: baru|perpanjangan|perubahan_data|penambahan_subklasifikasi|perubahan_kualifikasi|konversi_transisi), subklasifikasi_kode text[], kualifikasi_target (FK qualifications: k1|k2|k3|m|b), kualifikasi_saat_ini (nullable, FK qualifications), target_tanggal, skor_total, status_kesiapan (belum|hampir|siap). Petakan nilai lama "Baru"/"Perpanjangan"; kualifikasi lama: Menengah→M, Besar→B, Kecil→ tandai "perlu dipilih K1/K2/K3" dan minta pengguna memilih saat kasus dibuka; klasifikasi teks bebas lama disimpan ke kolom catatan_lama.
2. Form buat/edit kasus jadi wizard 3 langkah: (a) badan usaha & jenis permohonan, (b) pilih subklasifikasi dari katalog (multi-pilih, filter sesuai jenis_usaha) + kualifikasi target, (c) ringkasan syarat yang berlaku (ditarik dari requirements) sebelum disimpan.
3. Untuk perubahan_kualifikasi dan konversi_transisi, tampilkan field kualifikasi_saat_ini dan tautan ke /transition-verifications.
4. Halaman /cases/:id: tab Ringkasan, Syarat, Personel, Bukti, Rencana Aksi, Laporan (tab yang belum dibuat tampil "Segera hadir").
Kriteria terima:
- Kasus baru wajib memilih minimal 1 subklasifikasi.
- Tab Syarat menampilkan gabungan syarat umum + per subklasifikasi untuk kualifikasi target, tanpa duplikat kode_syarat.
- Kasus lama tetap bisa dibuka dan diedit.
```

## Prompt 4 — Tenaga kerja & SKK

```
Tugas: modul Personel & SKK per client.
Skema: personnel (id, client_id, nama, nik_last4, email, telepon, aktif bool), skk_certificates (id, personnel_id, nomor, subklasifikasi_skk, jenjang, kualifikasi_jabatan, terbit, berlaku_sampai, file_ref null), case_assignments (id, case_id, personnel_id, peran: pjbu|pjtbu|pjskbu|tenaga_ahli, subklasifikasi_kode).
Fitur:
1. Halaman /personnel: daftar personel per client, tambah/edit, unggah bukti SKK (pakai mekanisme upload dari Prompt 5 jika sudah ada; kalau belum, field file_ref dikosongkan dulu).
2. Di tab Personel kasus: tetapkan PJBU, PJTBU, PJSKBU, tenaga ahli per subklasifikasi.
3. Validasi otomatis (tampil sebagai temuan, bukan pemblokir):
   - Peran wajib per requirements tipe jumlah_personel/jenjang_skk terpenuhi.
   - Jenjang SKK >= jenjang_min (urutan jenjang dibaca dari app_settings "urutan_jenjang", dapat diubah admin).
   - SKK masih berlaku pada target_tanggal; peringatan jika berakhir < 90 hari.
   - Satu personel tidak ditugaskan sebagai PJ pada client lain dalam org yang sama (peringatan "potensi rangkap"). Tampilkan catatan bahwa pengecekan rangkap lintas badan usaha di luar aplikasi tetap harus dilakukan pengguna.
4. Tombol "Urus SKK" membuka Exum SKK (URL dari Secret EXUM_SKK_URL) di tab baru.
Kriteria terima:
- Personel dengan SKK kedaluwarsa memunculkan temuan merah.
- Rangkap PJ terdeteksi di dua client berbeda.
- Tidak ada NIK lengkap tersimpan.
```

## Prompt 5 — Bukti & dokumen (Ruang Simpan)

```
Tugas: unggah dan kelola bukti.
1. Migrasi evidence: tambah requirement_id null, file_ref, file_nama, mime, ukuran, storage (ruang_simpan|lokal), nomor_dokumen, terbit, berlaku_sampai, status (ada|kurang|kedaluwarsa|ditolak_internal), catatan. Pertahankan 9 kategori lama dan petakan ke dimensi: legalitas→legalitas; penjualan tahunan→penjualan; kemampuan keuangan→keuangan; tenaga kerja→tenaga_kerja; peralatan→peralatan; sertifikat SMAP, PANCEK, surat komitmen SMAP, bimtek SMAP→smap_smm.
2. Upload: PDF/JPG/PNG maks 10 MB, cek mime di server. Jika akun terhubung Ruang Simpan (token di Secret/OAuth yang sudah ada untuk /api/ruang-simpan), simpan ke Ruang Simpan dan simpan file_ref; jika tidak, simpan di Replit Object Storage dengan path per org. Unduh lewat URL bertanda tangan berumur pendek.
3. Tab Bukti kasus: daftar syarat yang butuh bukti → status per syarat, tombol unggah langsung dari syarat, status kedaluwarsa dihitung otomatis dari berlaku_sampai.
4. Isi otomatis profil perusahaan dari /api/ruang-simpan/company-profile ke client (tombol "Tarik dari Ruang Simpan", tampilkan beda sebelum menimpa).
Kriteria terima:
- Bukti tidak bisa diunduh oleh org lain.
- File > 10 MB atau tipe lain ditolak dengan pesan jelas.
- Status otomatis berubah jadi kedaluwarsa setelah tanggal lewat.
```

## Prompt 6 — Kalkulator kesiapan & rencana aksi

```
Tugas: mesin penilaian deterministik (tanpa AI).
1. Buat modul server scoring/engine.ts: input = kasus + syarat yang berlaku + personel + bukti + profil; output = { skor_total, per_dimensi: {dimensi: {skor, terpenuhi, total}}, status_kesiapan, temuan: [{requirement_id, kode_syarat, dimensi, tingkat: kritis|sedang|info, pesan, bukti_dibutuhkan, sumber, indikatif] }.
   - Tiap tipe_aturan punya evaluator sendiri (dokumen_ada, angka_minimal, jumlah_personel, jenjang_skk, boolean).
   - Skor dimensi = jumlah bobot terpenuhi / total bobot × 100, HANYA dari syarat final/ditelaah. Syarat draf dievaluasi tapi ditandai indikatif dan tidak masuk skor.
   - status: siap = semua syarat kritis terpenuhi & skor_total ≥ 90; hampir = ≥ 70; selain itu belum. Ambang dibaca dari app_settings.
2. Endpoint POST /api/cases/:id/score (simpan snapshot ke tabel case_scores dengan versi requirements yang dipakai) dan GET riwayat skor.
3. Setiap temuan yang belum ada action_items-nya → buat action_items (case_id, requirement_id, judul, pemilik_user_id null, tenggat null, status: terbuka|proses|selesai). Temuan yang sudah terpenuhi → tandai action item "selesai otomatis".
4. UI: kartu skor total + 6 kartu dimensi, daftar temuan dikelompokkan per dimensi, tombol "Hitung ulang", grafik riwayat skor. Tab Rencana Aksi: tabel bisa diedit (pemilik, tenggat, status), filter.
5. Tes unit untuk setiap evaluator dan 3 skenario kasus contoh.
Kriteria terima:
- Hitung ulang dua kali tanpa perubahan data menghasilkan skor sama dan tidak menggandakan action items.
- Syarat draf tidak memengaruhi skor tetapi tampil sebagai "indikatif".
- Tes unit lulus.
```

## Prompt 7 — Laporan PDF

```
Tugas: ekspor "Laporan Kesiapan SBU" sebagai PDF.
1. GET /api/cases/:id/report.pdf (render server-side, mis. Playwright/Chromium atau pustaka PDF yang sudah ada di repo). Isi: sampul (nama BU, jenis permohonan, subklasifikasi, kualifikasi target, tanggal, nomor laporan), ringkasan skor & status, matriks syarat vs kondisi per dimensi, daftar temuan, personel yang ditugaskan, daftar bukti & masa berlaku, rencana aksi, daftar sumber regulasi yang dipakai (dari kolom sumber), versi data syarat, dan halaman disclaimer.
2. Disclaimer wajib: "Laporan ini alat bantu persiapan mandiri, bukan penerbitan, verifikasi resmi, atau jaminan SBU. Verifikasi dan penerbitan SBU dilakukan oleh lembaga berwenang sesuai ketentuan. Syarat bertanda 'indikatif' belum ditelaah ahli."
3. White-label (hanya paket Konsultan, cek via gating Prompt 9; sebelum Prompt 9 ada, izinkan semua): logo & nama kantor dari /settings.
4. Simpan riwayat laporan (case_reports: case_id, nomor, dibuat_oleh, skor_snapshot_id, file_ref).
Kriteria terima:
- PDF terbuka rapi di A4, bahasa Indonesia, nomor halaman.
- Data di PDF sama dengan snapshot skor terakhir.
```

## Prompt 8 — Multi-klien & peran

```
Tugas: ruang kerja kantor konsultan.
1. Organisasi Clerk = kantor/perusahaan. Peran org: owner, staf, klien. Simpan pemetaan klien → client_id di tabel client_members (client_id, user_id, peran: klien_admin|klien_viewer).
2. Owner/staf: melihat semua client di org, membuat client baru, mengundang klien via email (pakai undangan Clerk), menugaskan staf ke client.
3. Klien: hanya melihat client & kasus miliknya, boleh mengunggah bukti dan mengisi personel, tidak boleh mengubah syarat, skor, atau menghapus kasus.
4. Dashboard kantor (/dashboard untuk owner/staf): tabel client × kasus aktif, skor, status, bukti kedaluwarsa, action items terlambat; filter & urutkan.
5. Pengguna perorangan tanpa org tetap bekerja seperti biasa dengan 1 client.
6. Semua aksi penting dicatat di audit_logs.
Kriteria terima:
- Uji 3 akun: owner, staf, klien — akses sesuai matriks peran (tulis matriksnya di replit.md).
- Klien dari client A tidak bisa melihat client B.
```

## Prompt 9 — Langganan Scalev & gating

```
Tugas: monetisasi via Scalev.
1. Tabel plans (kode: gratis|mandiri|bisnis|konsultan, nama, harga_bulanan, batas jsonb) dan subscriptions (org_or_user_id, plan_kode, status: aktif|tenggang|berakhir, mulai, aktif_sampai, scalev_order_id, sumber: scalev|manual|bundel_ebook).
   Batas awal (ubah via admin): gratis {clients:1, cases:1, pdf:false, pengingat:false, ai:false}; mandiri {clients:1, cases:3, pdf:true}; bisnis {clients:1, cases:-1, pdf:true, pengingat:true, ai:true}; konsultan {clients:10, cases:-1, pdf:true, white_label:true, pengingat:true, ai:true, tim:true}.
2. POST /api/webhooks/scalev: verifikasi signature dengan Secret SCALEV_WEBHOOK_SECRET, idempoten berdasarkan order id, petakan produk Scalev → plan_kode (pemetaan disimpan di tabel scalev_products, dikelola admin). Pembayaran sukses → aktifkan/perpanjang; refund/batal → status berakhir.
3. Kode bundel: tabel redeem_codes untuk pembeli Ebook+Toolkit (aktivasi Mandiri 3 bulan). Halaman /redeem.
4. Middleware requireFeature(feature) dan checkLimit(resource); UI menampilkan kunci dan tombol "Tingkatkan paket".
5. Halaman /pricing (publik) dan /billing (status paket, riwayat, tautan checkout Scalev dari Secret per paket). Tenggang 7 hari setelah berakhir: data tetap bisa dibaca, tidak bisa membuat kasus baru.
6. Admin: /admin/subscriptions untuk aktivasi manual.
Kriteria terima:
- Simulasi webhook (curl dengan signature valid) mengaktifkan paket; signature salah → 401; webhook ganda tidak menggandakan masa aktif.
- Paket gratis tidak bisa membuat kasus kedua atau unduh PDF.
```

## Prompt 10 — Halaman publik, legal, onboarding

```
Tugas: siap dipakai pelanggan baru.
1. Landing page / (publik): janji produk "Tahu persis apa yang kurang untuk SBU Anda, lalu selesaikan dengan rencana aksi", 3 langkah cara kerja, fitur, untuk siapa (kontraktor, konsultan, kantor konsultan), harga (dari plans), FAQ, disclaimer independensi, CTA daftar. Tautan ke ebook "SBU & SKK Tanpa Bingung" (URL dari Secret EBOOK_URL).
2. Halaman /syarat-layanan dan /kebijakan-privasi (template bahasa Indonesia sesuai UU PDP; tandai bagian yang perlu ditinjau hukum dengan [TINJAU]).
3. Onboarding: pilih tipe (kontraktor/konsultan/kantor konsultan) → isi/tarik profil badan usaha → buat kasus pertama lewat wizard → tampilkan skor pertama. Checklist onboarding di dashboard sampai 4 langkah selesai.
4. Halaman /bantuan berisi panduan singkat per modul.
5. SEO dasar: title, meta description, Open Graph.
Kriteria terima:
- Pengguna baru dapat sampai skor pertama < 10 menit tanpa bantuan.
- Lighthouse mobile ≥ 85 untuk landing page.
```

## Prompt 11 — Pengingat masa berlaku (v1.1)

```
Tugas: pengingat otomatis (fitur paket bisnis & konsultan).
1. Tabel reminders (id, org_id, client_id, entitas: sbu|skk|bukti|action_item, entitas_id, tanggal_jatuh_tempo, offset_hari, terkirim_pada, kanal: email|whatsapp).
2. Job harian (Replit Scheduled Deployment atau cron endpoint terlindungi Secret CRON_TOKEN) untuk SBU (masa berlaku kasus), SKK, bukti, dan action items dengan offset 90/30/7/0 hari (bisa diatur per org).
3. Email via penyedia di Secret (mis. Resend). WhatsApp opsional lewat webhook generik (Secret WA_WEBHOOK_URL), nonaktif jika kosong.
4. Ringkasan mingguan untuk owner kantor: daftar jatuh tempo 30 hari ke depan.
5. Pengaturan notifikasi di /settings; tautan berhenti berlangganan di email.
Kriteria terima:
- Endpoint cron tanpa token → 401.
- Pengingat tidak terkirim dua kali untuk offset yang sama.
```

## Prompt 12 — AI per temuan (v1.1)

```
Tugas: tombol "Jelaskan & sarankan" pada setiap temuan (paket bisnis & konsultan).
1. POST /api/findings/explain { case_id, requirement_id }. Konteks yang dikirim ke model HANYA: data syarat (judul, deskripsi, parameter, sumber, status_verifikasi), kondisi kasus terkait syarat itu, dan bukti/personel terkait. Jangan kirim NIK, email, atau telepon.
2. System prompt: "Kamu asisten persiapan SBU. Jawab dalam bahasa Indonesia, maksimal 150 kata, format: Masalah, Kenapa penting, Langkah perbaikan (maks 3), Sumber. Gunakan hanya konteks yang diberikan. Jika konteks tidak cukup, katakan 'Perlu konfirmasi ke ketentuan resmi atau Telaah Ahli'. Jangan menjanjikan kelulusan. Jika status syarat draf, sebutkan bahwa syarat masih indikatif."
3. Model & API key dari Secrets; batas kuota per org per bulan dari plans; cache jawaban per (requirement versi, kondisi hash).
4. Simpan ai_logs (org_id, user_id, case_id, requirement_id, prompt_hash, jawaban, token, created_at) dan tombol 👍/👎.
5. Tombol "Minta Telaah Ahli" di bawah jawaban (mengarah ke Prompt 13).
Kriteria terima:
- Jawaban selalu menyertakan sumber dari kolom sumber.
- Pertanyaan di luar konteks ditolak dengan sopan.
- Kuota habis → pesan upgrade, bukan error.
```

## Prompt 13 — Telaah Ahli & Radar Regulasi (v1.2)

```
Tugas A – Telaah Ahli (add-on berbayar):
1. Tabel review_requests (case_id, diminta_oleh, status: menunggu_bayar|antre|ditelaah|selesai, ahli_user_id, catatan, hasil jsonb, scalev_order_id). Pembayaran per kasus lewat produk Scalev terpisah.
2. Peran "ahli" (daftar email di Secret EXPERT_EMAILS): /expert antrean, buka kasus read-only, beri catatan per temuan (setuju/koreksi + alasan), ringkasan akhir. Kasus mendapat badge "Ditelaah ahli – tanggal".
3. Hasil telaah ikut dalam PDF (bagian "Catatan Telaah Ahli").

Tugas B – Radar Regulasi:
1. Tabel reg_changes (id, judul_peraturan, nomor, tanggal, ringkasan, tautan_sumber, requirement_ids int[], status: usulan|disetujui).
2. Admin membuat usulan perubahan (bisa diisi otomatis oleh agen Kurator Regulasi melalui POST /api/admin/reg-changes dengan token REG_AGENT_TOKEN — status selalu "usulan"). Hanya admin yang bisa menyetujui; persetujuan memperbarui requirements (versi naik).
3. Saat disetujui: tandai kasus aktif yang memakai requirement terdampak, tampilkan banner "Ada perubahan ketentuan yang memengaruhi kasus ini – hitung ulang", dan kirim notifikasi.
4. Halaman /regulations yang sudah ada menampilkan linimasa reg_changes yang disetujui.
Kriteria terima:
- Agen tidak bisa langsung mengubah requirements final.
- Kasus terdampak ditandai setelah persetujuan.
```

## Prompt 14 — Pengerasan, uji & siap rilis

```
Tugas: siapkan rilis berbayar.
1. Keamanan: rate limit untuk API publik & webhook, header keamanan, CORS ketat, cek ulang otorisasi di semua endpoint (buat daftar endpoint + aturan aksesnya di replit.md), sanitasi nama file.
2. Kualitas data: tes end-to-end (Playwright) untuk alur: daftar → onboarding → buat kasus → tambah personel → unggah bukti → hitung skor → unduh PDF → upgrade paket (webhook simulasi).
3. Observabilitas: log error terstruktur, halaman /admin/health (status DB, storage, email, Scalev webhook terakhir), metrik dasar (pengguna aktif, kasus dibuat, PDF diunduh, konversi paket).
4. Kinerja: indeks DB untuk kolom org_id, client_id, case_id, berlaku_sampai; halaman utama < 2 detik.
5. Backup: skrip ekspor data per org (JSON + file) untuk permintaan pengguna (hak akses data UU PDP) dan penghapusan akun.
6. Perbarui replit.md: arsitektur, matriks peran, daftar Secrets yang dibutuhkan, cara menjalankan tes, checklist rilis.
Kriteria terima:
- Semua tes lulus.
- Checklist rilis di replit.md terisi: katalog ≥ 20 subklasifikasi berstatus ditelaah/final, 10 kasus uji dibandingkan dengan penilaian ahli (selisih ≤ 10%), Scalev live teruji, halaman legal ditinjau.
```

## Prompt 15 — Tutor Regulasi SBU (v1.2)

```
Tugas: fitur "Tutor Regulasi SBU" — asisten belajar dan tanya-jawab yang HANYA menjawab dari teks regulasi resmi di pustaka aplikasi.

A. Pustaka regulasi (admin)
1. Tabel reg_documents (id, jenis: uu|pp|permen|kepdirjen|peraturan_lembaga|lainnya, nomor, tahun, judul, tanggal_ditetapkan, tanggal_berlaku, status: berlaku|dicabut|diubah, menggantikan_id, diganti_oleh_id, file_ref, sumber_url, diverifikasi_oleh, diverifikasi_pada).
2. Tabel reg_chunks (id, document_id, rujukan: mis. "Pasal 12 ayat (3)" atau "Lampiran II butir B.3", teks, embedding vector, urutan). Gunakan pgvector bila Postgres; jika tidak tersedia, gunakan pencarian full-text sebagai cadangan.
3. Halaman /admin/regulations: unggah PDF resmi → ekstrak teks → pecah per pasal/ayat/lampiran (tampilkan pratinjau, admin bisa koreksi batas pasal) → simpan + buat embedding. Dokumen baru berstatus belum terbit sampai admin klik "Terbitkan".
4. Dokumen awal yang disiapkan admin: PP 28/2025, Permen PU 6/2025, Kepdirjen Bina Konstruksi 281/2026, UU 2/2017 tentang Jasa Konstruksi beserta perubahannya, dan regulasi terkait SBU/SKK/LSBU/SMAP. Untuk perbandingan: PP 5/2021 dan Permen PUPR 6/2021 berstatus dicabut.

B. Mode pengguna di /tutor
1. Tanya: jawaban dari potongan pasal hasil pencarian (top-k 8, hanya dokumen berstatus berlaku kecuali pengguna memilih "termasuk aturan lama"). Setiap klaim diberi sitasi [Nomor Peraturan – Pasal]. Sitasi bisa diklik untuk membuka teks pasal.
2. Belajar: modul per topik (Dasar SBU, Klasifikasi & Kualifikasi, Persyaratan per Dimensi, Tenaga Kerja & SKK, Peran LSBU, Transisi Aturan, Kepatuhan Berkelanjutan). Tiap modul: ringkasan (disusun admin, dengan sitasi), 5 soal kuis, skor tersimpan, badge selesai (bukan sertifikat resmi). Tabel learning_modules, quiz_items, learning_progress.
3. Bandingkan: pilih topik → tampilkan dua kolom aturan lama vs baru dengan sitasi masing-masing, plus ringkasan perubahan.
4. Kasus: jika dibuka dari /cases/:id, konteks ditambah data kasus & temuan kalkulator (tanpa data pribadi), dan jawaban mengaitkan pasal dengan kondisi kasus.

C. Aturan jawaban (system prompt)
"Kamu Tutor Regulasi SBU dari Gustafta, independen dan tidak mewakili Kementerian PU, LPJK, atau LSBU. Jawab dalam bahasa Indonesia yang jelas. Gunakan HANYA potongan regulasi yang diberikan. Setiap pernyataan normatif wajib bersitasi. Jika tidak ada dasar di potongan, jawab: 'Saya tidak menemukan ketentuan ini dalam regulasi yang tersedia. Silakan cek teks resmi atau ajukan Telaah Ahli.' Jangan mengarang nomor pasal, angka, atau tanggal. Bedakan aturan berlaku dan aturan lama. Jangan memberi jaminan hasil sertifikasi. Akhiri dengan 1 langkah praktis bila relevan."
Setelah model menjawab, validasi di server: setiap sitasi harus cocok dengan chunk yang dikirim; jika ada sitasi tidak valid, hapus kalimatnya dan beri tanda "perlu dicek".

D. Mutu & biaya
1. Tabel eval_questions (pertanyaan, jawaban_acuan, rujukan_wajib). Halaman /admin/tutor-eval menjalankan semua pertanyaan uji dan menampilkan skor (sitasi benar, menolak bila di luar pustaka). Target ≥ 90% sebelum dibuka untuk pengguna; jalankan ulang setiap ada dokumen baru.
2. Kuota per paket dari plans (gratis 5 tanya/bulan; mandiri terbatas; bisnis & konsultan penuh; pembeli bundel ebook: Mode Belajar penuh). Cache jawaban untuk pertanyaan identik per versi pustaka.
3. Log tutor_logs + tombol 👍/👎 + "Laporkan jawaban keliru" (masuk antrean admin).
4. Gunakan mesin RAG yang sama untuk fitur "Jelaskan" di Prompt 12.

Kriteria terima:
- 100% jawaban normatif memiliki sitasi yang valid ke reg_chunks.
- Pertanyaan di luar pustaka ditolak dengan pesan standar.
- Dokumen berstatus dicabut tidak dipakai kecuali mode Bandingkan / opsi aturan lama.
- Skor eval ≥ 90% tercatat di /admin/tutor-eval.
```

## Prompt 16 — Tiga Pustaka Kasus & Studi Banding (v1.3)

```
Tugas: perluas fitur Pustaka Kasus menjadi tiga koleksi modul: SBU, SKK, dan PERIZINAN. Ini alat belajar/persiapan, bukan teks regulasi, keputusan sertifikasi, atau catatan pengalaman nyata yang boleh dikarang.
1. Tabel case_library memakai kode unik dan modul enum SBU|SKK|PERIZINAN; segmen text[] (Kontraktor|Konsultan|Tenaga kerja konstruksi); jenis_permohonan enum Baru|Perpanjangan|Perubahan data; tema; judul; gejala; dugaan_akar_masalah; diagnosis jsonb (daftar pertanyaan); solusi_langkah jsonb (daftar objek dengan urutan dan langkah); bukti_persiapan jsonb (daftar bukti); peran_lembaga; hasil_diharapkan; hasil_aktual nullable; pelajaran_studi_banding; rujukan jsonb (daftar objek dengan url, nama, locator); batas_penerapan; asal_kasus enum Skenario studi banding|Kasus nyata bersumber|Laporan kasus belum diverifikasi; status_telaah enum Draf|Ditelaah|Final; versi. Untuk kasus nyata dan telaah: sumber_kejadian jsonb nullable, kronologi_tersamar jsonb nullable, bukti_kejadian_privat_refs jsonb nullable, izin_penggunaan jsonb nullable, ditelaah_oleh nullable, ditelaah_pada nullable, versi_sumber jsonb, alasan_perubahan; seluruhnya kosong pada seed skenario. Metadata privat tidak ikut publikasi. Kolom tambahan integrasi: requirement_kode_terkait text[], rujukan_chunk_ids int[], tag text[]. Jangan mengarang kode requirement atau memasangkan aturan tanpa telaah.
2. Impor JSONL dari /seed/seed_SBU.jsonl, /seed/seed_SKK.jsonl, /seed/seed_PERIZINAN.jsonl, atau /seed/seed_semua_modul.jsonl (jangan mengimpor gabungan dan tiga bagian sebagai salinan berbeda). Isi awal dari Pustaka Kasus SBU, SKK & Perizinan Usaha: 150 skenario, 50 per modul, semuanya Draf, hasil_aktual dan sumber_kejadian kosong. Gunakan upsert berdasarkan kode; perubahan versi tidak menimpa kasus nyata yang sudah ditelaah tanpa persetujuan admin. Simpan log impor dan laporkan baris gagal. Tidak ada data produksi baru sebelum kriteria terima lulus.
3. Admin CRUD /admin/case-library memisahkan asal kasus dari status telaah. Draf dan Ditelaah hanya untuk admin/penelaah. Hanya Final dapat ditampilkan kepada pengguna, dengan label asal yang selalu terlihat. Dilarang mengubah skenario menjadi kasus nyata hanya dengan mengganti label. Simpan penelaah, tanggal telaah, versi sumber, dan alasan perubahan. Perubahan regulasi/skema memicu antrean telaah ulang serta pembatasan publikasi sampai disetujui.
4. Halaman /kasus memiliki tab SBU, SKK, Perizinan Usaha; filter segmen, jenis permohonan, tema, asal; pencarian gejala/judul. Detail menampilkan Gejala → Dugaan akar → Diagnosis → Langkah → Bukti → Peran lembaga → Hasil diharapkan/aktual → Pelajaran → Rujukan/batas. Hasil diharapkan tidak pernah ditampilkan sebagai keberhasilan aktual.
5. Mode Bandingkan 2–3 kasus menampilkan konteks, bukti, jenis permohonan, sumber, asal, dan faktor yang dapat mengubah penanganan. Tidak menyimpulkan peluang lulus, tenggat, tarif, atau ketentuan universal dari contoh. Pada perizinan, Perpanjangan juga dapat berarti pemeriksaan keberlanjutan/status; jangan membuat kewajiban perpanjangan NIB tahunan. Pada SKK/PKB, gunakan skema dan aturan resmi yang spesifik; tanpa naskah/rujukan yang cukup, tandai perlu konfirmasi.
6. Terapkan ke kasus saya: pengguna memilih kasus kerja sendiri dan meninjau kesesuaian konteks. Salin langkah menjadi action_items setelah konfirmasi, dengan kunci unik (target_case_id, kode_pustaka, versi, urutan) agar tidak duplikat. Jangan otomatis mengubah izin, status sertifikat, nilai kredit PKB, atau data pribadi. Setiap langkah boleh ditandai tidak relevan dengan alasan.
7. Temuan kalkulator menampilkan maks. 3 Kasus serupa berdasarkan modul, segmen, tema, dan requirement_kode yang sudah diverifikasi. Tutor Mode Kasus boleh memakai kasus Final sebagai konteks tambahan berlabel Pustaka Kasus Gustafta — bahan studi banding, bukan teks regulasi. Klaim persyaratan tetap bersumber dari reg_chunks Final dan menyebut locator, bukan dari skenario. Untuk tenaga kerja, filter SKK pribadi/penugasan relevan; tidak mewajibkan NIB kepada semua pegawai konstruksi.
8. Form Usulkan kasus nyata masuk antrean Laporan kasus belum diverifikasi, bukan otomatis Kasus nyata bersumber. Kumpulkan kronologi, jenis permohonan, bukti masalah/tindakan/hasil, sumber kejadian, izin penggunaan, dan batas kerahasiaan. Bukti asli berada di penyimpanan privat dengan akses terbatas; versi publik anonim, NIK/nomor lengkap dokumen/kontak serta rahasia klien disamarkan dan diperiksa manusia. Jangan menjanjikan penghapusan data otomatis tanpa pengujian. Hanya penelaah dapat menetapkan Kasus nyata bersumber setelah memeriksa bukti dan hasil aktual. Tidak ada nama klien, tanggal kejadian, atau angka keberhasilan buatan.
Kriteria terima:
- Impor menghasilkan tepat 50 kasus per modul: 20 Baru, 15 Perpanjangan, 15 Perubahan data; total 150 kode unik, semua Draf dan Skenario studi banding, hasil aktual kosong.
- Mengimpor ulang tidak menambah duplikat; seluruh kegagalan dilaporkan.
- Non-admin tidak dapat mengakses Draf/Ditelaah; setiap kasus publik Final tetap menampilkan asal dan batas penerapan.
- Filter serta Bandingkan bekerja per modul; kasus mirip tidak dipasangkan melalui kode aturan yang belum ditelaah.
- Terapkan ke kasus saya tidak membuat duplikat atau melakukan pengajuan/perubahan izin otomatis.
- Kasus nyata tanpa bukti/izin/penelaah tidak bisa dipromosikan; bukti privat tidak tampil pada materi publik.
- NIB tidak diberi jadwal perpanjangan tahunan universal; angka kredit PKB dan tenggat konversi SBU tidak dibuat dari asumsi.
```

## Prompt 17 — Modul LSBU (v1.2)

```
Tugas: modul yang menjelaskan dan mempersiapkan pengajuan ke LSBU (Lembaga Sertifikasi Badan Usaha), lembaga yang diamanatkan Undang-Undang Jasa Konstruksi untuk melaksanakan sertifikasi badan usaha. Aplikasi TIDAK menggantikan LSBU.
1. Tabel lsbu_directory (nama, jenis_usaha_dilayani: kontraktor|konsultan|keduanya, status_lisensi, nomor_lisensi, situs_resmi, kontak_resmi, sumber_data_url, diverifikasi_pada, aktif). Diisi admin dari sumber resmi; tampilkan tanggal verifikasi data; tanpa peringkat/rekomendasi komersial.
2. Halaman /lsbu: (a) penjelasan peran LSBU dengan sitasi dari Tutor (reg_chunks), (b) beda LSBU (badan usaha) vs LSP (tenaga kerja) vs regulator, (c) linimasa alur: OSS/NIB → persiapan di aplikasi → pengajuan ke LSBU → verifikasi & validasi → perbaikan bila diminta → penerbitan SBU → masa berlaku & perpanjangan, (d) direktori LSBU dengan filter.
3. "Paket Siap Ajukan" di /cases/:id: tombol ekspor ZIP berisi folder per dimensi, dokumen dengan penamaan baku (mis. 01_Legalitas_NIB.pdf), daftar_isi.pdf, Laporan Kesiapan (Prompt 7), dan checklist kelengkapan. Hanya aktif jika semua syarat kritis berstatus terpenuhi; jika belum, tampilkan daftar yang kurang.
4. Pelacak pengajuan: tabel lsbu_submissions (case_id, lsbu_id, tanggal_ajukan, nomor_permohonan, status: diajukan|diminta_perbaikan|diverifikasi|terbit|ditolak, catatan, tanggal_terbit, nomor_sbu, berlaku_sampai). Status "diminta_perbaikan" dengan catatan → otomatis membuat action items. Status "terbit" → isi masa berlaku SBU dan aktifkan pengingat (Prompt 11).
5. Teks wajib di halaman: "Penilaian dan penerbitan SBU sepenuhnya kewenangan LSBU sesuai ketentuan. SBU Accelerator membantu persiapan dan tidak mewakili LSBU mana pun."
6. Persiapan kemitraan (flag nonaktif): mode "Mitra LSBU/Asosiasi" — pengguna dapat membagikan Paket Siap Ajukan via tautan berbatas waktu (dengan persetujuan eksplisit dan log akses). Tidak ada akses LSBU ke data tanpa persetujuan pengguna.
Kriteria terima:
- Paket Siap Ajukan tidak bisa diunduh bila syarat kritis belum terpenuhi.
- Status diminta_perbaikan membuat action items; status terbit mengaktifkan pengingat.
- Tautan berbagi kedaluwarsa sesuai waktu dan tercatat di audit_logs.
```

## Prompt 18 — Jembatan ke Klinik & Workroom (sisi SBU Accelerator)

```
Tugas: hubungkan SBU Accelerator dengan Klinik Konsultasi dan Workroom di Gustafta OS (gustafta.my.id). Jangan membangun chat/ruang kerja sendiri.
1. Tombol "Konsultasikan ke Klinik" pada: setiap temuan kalkulator, Paket Siap Ajukan yang terkunci, dashboard /profesional. Klik → modal persetujuan berbagi data (daftar data yang dibagikan, bisa dicentang) → buka https://gustafta.my.id/klinik-konsultasi dengan loket SBU–SKK dan token konteks (handoff_token).
2. Tombol "Minta Pendampingan" → pilih tingkat (Telaah Ahli / Pendampingan / Penyusunan Dokumen / Pendampingan SKK) → checkout Scalev (URL per tingkat dari Secrets) → setelah lunas, panggil API Gustafta OS untuk membuat Workroom dari templat persiapan_sbu atau persiapan_skk.
3. Endpoint keluar (server-to-server, Secret GUSTAFTA_OS_API_KEY):
   - POST {GUSTAFTA_OS_URL}/api/handoff → kirim { case_id, jenis_permohonan, subklasifikasi, kualifikasi_target, skor, temuan[], action_items[], dokumen_refs[] (file_ref Ruang Simpan, bukan file) }, terima handoff_token berumur 30 menit.
   - POST {GUSTAFTA_OS_URL}/api/workrooms → { template, handoff_token, scalev_order_id } → simpan workroom_id di tabel case_workrooms (case_id, workroom_id, tingkat, status, dibuat_pada).
4. Endpoint masuk (webhook, verifikasi signature Secret GUSTAFTA_OS_WEBHOOK_SECRET): POST /api/webhooks/workroom dengan event: stage_changed, gate_approved, notes_added, action_items_updated, ready_to_submit, closed. Efek: perbarui action_items, simpan catatan ahli (tampil di tab Ringkasan & PDF), badge "Didampingi Workroom", buka Paket Siap Ajukan bila ready_to_submit + syarat kritis terpenuhi, cabut akses saat closed.
5. Tab "Pendampingan" di /cases/:id: status Workroom, tahap & gerbang, tautan "Buka Workroom".
6. Tampilkan batas layanan sebelum checkout: tidak menjamin terbit; tidak menyediakan tenaga ahli/joki; biaya resmi LSBU/LSP terpisah.
Kriteria terima:
- Tanpa persetujuan, tidak ada data terkirim.
- Webhook bersignature salah → 401; event ganda idempoten.
- Event ready_to_submit membuka Paket Siap Ajukan hanya bila syarat kritis terpenuhi.
```

## Prompt 19A — Penyempurnaan Workroom domain SBU/SKK (berdasarkan kondisi saat ini)

```
Konteks: Workroom di gustafta.my.id/workroom sudah ada: form "Buat Workroom Baru" (Bidang/Domain, Judul, Instansi, Nilai Pagu/HPS, Catatan Awal) dan halaman /workroom/:id berisi Tahapan Kerja (klik untuk tandai aktif), Analisis AI (tombol Jalankan Analisis), Gerbang Manusia ◆ (input teks), dan Jurnal Kerja (catatan). Untuk domain SBU, tahap saat ini: Identifikasi Klasifikasi & Subklasifikasi → Cek Persyaratan (PJBU/PJTBU/SKK) → Penyusunan Berkas → Pengajuan ke LSBU/OSS → Review & Gerbang Manusia ◆ → Terbit & Arsip. Pertahankan domain lain (tender, K3) tetap berfungsi.

Tugas:
1. Form per domain: field dinamis berdasarkan domain (konfigurasi di tabel workroom_domains.fields jsonb).
   - SBU: nama badan usaha, jenis usaha (kontraktor|konsultan), jenis permohonan (baru|perpanjangan|perubahan_data|penambahan_subklasifikasi|perubahan_kualifikasi|konversi_transisi), subklasifikasi (multi, dari katalog SBU Accelerator via API; fallback teks), kualifikasi target (K1|K2|K3|M|B, dari data master kualifikasi), target tanggal, ID kasus SBU Accelerator (opsional, untuk impor).
   - SKK: nama peserta, subklasifikasi/jabatan kerja, jenjang target, LSP tujuan (opsional), target tanggal.
   - Tender tetap memakai instansi & pagu/HPS.
   Gunakan kualifikasi K1/K2/K3/M/B sesuai Permen PU 6/2025 & Kepdirjen Bina Konstruksi 281/2026, dengan keterangan golongan (Kecil/Menengah/Besar). Label "Gedung · K2" sudah benar formatnya; tambahkan kode subklasifikasi. Data lama berlabel Kecil/Menengah/Besar dipetakan: Menengah→M, Besar→B, Kecil→ wajib dipilih K1/K2/K3.
2. Tahapan baku SBU (urutan diperbaiki, gerbang SEBELUM pengajuan):
   Intake ◆ → Identifikasi Subklasifikasi & Kualifikasi → Cek Persyaratan (legalitas, penjualan/pengalaman, keuangan, PJBU/PJTBU/PJSKBU & SKK, peralatan, SMAP) → Pemenuhan Berkas → QA & Gerbang Siap Ajukan ◆ → Pengajuan ke LSBU ◆ → Tindak Lanjut LSBU → Terbit & Arsip.
   SKK: Intake ◆ → Pemetaan Jenjang & LSP → Portofolio Pengalaman → Persiapan Uji → Gerbang Siap Ajukan ◆ → Pengajuan ke LSP (oleh peserta) → Hasil & Pencatatan SKK.
   Tiap tahap: daftar tugas (judul, PIC, tenggat, status, lampiran), syarat selesai, gerbang terkait. Tahap tidak bisa ditandai selesai bila tugas wajib/gerbangnya belum beres (admin bisa override dengan alasan, tercatat).
3. Analisis AI terstruktur: output JSON {skor_per_dimensi, kekurangan[{dimensi, pesan, tingkat, sitasi[], indikatif], rekomendasi[]}. Gunakan SBU Coach/Tutor Regulasi (RAG dari teks resmi PP 28/2025, Permen PU 6/2025, Kepdirjen Bina Konstruksi yang berlaku, UU Jasa Konstruksi); jika data matriks syarat dari SBU Accelerator tersedia, gunakan itu sebagai sumber utama. Tampilkan kartu skor + daftar kekurangan + sitasi; tombol "Jadikan tugas" per kekurangan; riwayat analisis tersimpan. Teks dasar diganti: "berbasis PP 28/2025, Permen PU 6/2025, dan ketentuan turunannya. Hasil indikatif; penilaian resmi oleh LSBU."
4. Gerbang ◆ baku: tabel workroom_gates (tahap, judul, penyetuju_peran: klien|ahli|operator, status: menunggu|disetujui|ditolak, alasan, diputuskan_oleh, diputuskan_pada). Gerbang dibuat otomatis dari templat; masih bisa menambah gerbang manual. Agen dan pengguna tanpa peran penyetuju tidak bisa memutuskan.
5. Dokumen: panel Berkas per syarat — lampirkan dari Ruang Simpan atau unggah; status ada|kurang|kedaluwarsa; versi; draf buatan agen berlabel DRAF dan wajib dikonfirmasi klien sebelum dipakai.
6. Personel (domain SBU): daftar PJBU/PJTBU/PJSKBU & tenaga ahli dengan SKK (jenjang, masa berlaku); impor dari SBU Accelerator; peringatan kedaluwarsa & potensi rangkap.
7. Anggota & kolaborasi: undang anggota dengan peran klien|pendamping|operator|pengamat; komentar per tugas dengan mention; notifikasi email/in-app; Jurnal Kerja tetap ada dan otomatis mencatat peristiwa (tahap berubah, gerbang diputuskan, berkas diunggah).
8. Pelacak LSBU (domain SBU) / LSP (domain SKK): LSBU/LSP tujuan, tanggal ajukan, nomor permohonan, status (diajukan|diminta_perbaikan|diverifikasi|terbit|ditolak), catatan perbaikan → tugas otomatis di tahap Tindak Lanjut; saat terbit: nomor & masa berlaku → kirim ke SBU Accelerator untuk pengingat.
9. Layanan & batas: tampilkan tingkat layanan & status order Scalev di header; banner batas layanan (tidak menjamin terbit; tidak menyediakan/menyewakan tenaga ahli; tidak ada joki uji; biaya resmi LSBU/LSP terpisah); deteksi permintaan terlarang di komentar/jurnal → peringatan & catat.
10. Integrasi & jejak: handoff dari SBU Accelerator mengisi form, tugas, berkas, personel; webhook ke SBU Accelerator untuk event tahap/gerbang/catatan/siap ajukan/selesai; tombol "Eskalasi ke Klinik"; panel "Kasus serupa" dari Pustaka Kasus; audit log; ekspor Ringkasan Workroom (PDF); status Arsip (read-only) setelah selesai dan akses pendamping dicabut.
11. Header Workroom: judul, domain, badan usaha/peserta, subklasifikasi, kualifikasi, progres (% tugas & gerbang), tenggat terdekat, tautan ke kasus SBU Accelerator.
Kriteria terima:
- Workroom SBU baru memakai field & tahapan baru; Workroom lama tetap terbuka (data dipetakan).
- Tahap "Pengajuan ke LSBU" tidak bisa aktif sebelum Gerbang Siap Ajukan disetujui ahli.
- Analisis AI menampilkan sitasi; kekurangan bisa dijadikan tugas.
- Klien tidak bisa menyetujui gerbang ahli; agen tidak bisa menyetujui gerbang apa pun.
- Status "diminta_perbaikan" membuat tugas otomatis; status "terbit" tersinkron ke SBU Accelerator.
```

## Prompt 19 — Templat Workroom "Persiapan SBU" & "Persiapan SKK" (sisi Gustafta OS)

```
Konteks: Gustafta OS (gustafta.my.id/os) memiliki pilar Coach, Claw, Workroom, Academy, Competency & Monetization, serta Klinik Konsultasi dengan loket. Workroom = ruang kerja manusia + agen dengan analisis AI dan gerbang persetujuan ◆.
Tugas: audit dulu model data Workroom & Klinik yang sudah ada, lalu tambahkan tanpa merusak fitur lain:
1. Loket "SBU–SKK" di Klinik: menerima handoff_token (POST /api/handoff dari SBU Accelerator, verifikasi API key), menampilkan ringkasan kasus ke AI & operator. AI menjawab dengan Tutor/SBU Coach (sitasi pasal); tombol "Eskalasi ke operator" dan "Lanjut ke Workroom".
2. Templat Workroom persiapan_sbu dengan tahap: Intake ◆(klien setuju lingkup & biaya) → Diagnosis ◆(ahli setujui daftar kekurangan) → Pemenuhan ◆(klien konfirmasi kebenaran data) → QA ◆(ahli nyatakan siap ajukan) → Pengajuan ◆(klien setujui pengajuan ke LSBU) → Pascapengajuan.
   Templat persiapan_skk: Intake → Pemetaan jenjang & LSP → Portofolio pengalaman → Persiapan uji → Pengajuan ke LSP (oleh peserta) → Pencatatan SKK.
3. POST /api/workrooms {template, handoff_token, scalev_order_id}: buat Workroom, isi otomatis temuan → tugas, dokumen_refs → lampiran (baca dari Ruang Simpan dengan izin klien). Peran: klien, pendamping (ahli/mitra), operator, agen.
4. Agen Claw di Workroom: Penilai (analisis kekurangan), Penyusun Dokumen (draf surat pernyataan, daftar personel, rekap pengalaman dari data klien — selalu berlabel DRAF, wajib dikonfirmasi klien), Pemeriksa QA (cek silang syarat vs bukti). Agen tidak boleh melewati gerbang ◆.
5. Webhook keluar ke SBU Accelerator (POST /api/webhooks/workroom, bertanda tangan) untuk event stage_changed, gate_approved, notes_added, action_items_updated, ready_to_submit, closed.
6. Mitra pendamping (pilar Competency & Monetization): profil mitra terkurasi, penugasan otomatis/manual, komisi platform dari order Scalev, rating klien setelah closed.
7. Pagar layanan: teks batas layanan di awal Workroom; deteksi kata kunci permintaan terlarang (mis. "pinjam nama", "sewa SKK", "joki") → tolak & catat; akses pendamping dicabut otomatis saat closed; semua aksi di audit log.
Kriteria terima:
- Workroom terbentuk dari handoff dengan tugas & lampiran terisi.
- Gerbang ◆ tidak bisa dilewati agen.
- SBU Accelerator menerima semua event dan statusnya sinkron.
```

---

## Daftar Secrets yang dibutuhkan

| Secret | Untuk |
| --- | --- |
| ADMIN_EMAILS | Admin katalog & langganan |
| EXPERT_EMAILS | Peran ahli (Telaah Ahli) |
| EXUM_SKK_URL, EBOOK_URL | Tautan ekosistem |
| SCALEV_WEBHOOK_SECRET, SCALEV_CHECKOUT_* | Pembayaran |
| RESEND_API_KEY (atau penyedia email lain), WA_WEBHOOK_URL | Pengingat |
| AI_API_KEY, AI_MODEL | AI per temuan |
| CRON_TOKEN, REG_AGENT_TOKEN | Job harian & agen Kurator Regulasi |
| Kredensial Ruang Simpan (yang sudah ada) | Bukti & profil perusahaan |
| EMBEDDING_MODEL (opsional) | Pencarian semantik Tutor Regulasi |
| GUSTAFTA_OS_URL, GUSTAFTA_OS_API_KEY, GUSTAFTA_OS_WEBHOOK_SECRET, SCALEV_CHECKOUT_PENDAMPINGAN_* | Klinik, Workroom & layanan pendampingan |

## Perbaikan dibanding prompt versi awal

- Ditambah **Prompt 0** (konteks, posisi independen, aturan keamanan) dan **Prompt 1** (audit + isolasi data) agar Replit tidak merusak fitur lama.
- Urutan diperbaiki: personel & bukti dibuat **sebelum** kalkulator, karena kalkulator membutuhkan datanya.
- Setiap prompt punya **kriteria terima** yang bisa diuji.
- Syarat diberi **tipe aturan + parameter** (bukan teks bebas), versi, riwayat, dan alur draf → ditelaah → final.
- Seed data memakai **dummy berlabel**, tidak mengarang angka ambang resmi.
- Ditambah langganan lengkap (webhook idempoten, kode bundel ebook, masa tenggang), halaman legal/UU PDP, Telaah Ahli, Radar Regulasi, dan tahap rilis.
- Ditambah Prompt 15–17: Tutor Regulasi (hanya dari teks resmi, sitasi divalidasi server), tiga Pustaka Kasus & Studi Banding (150 skenario Draf; pengalaman nyata memerlukan bukti, izin, dan telaah; isi awal di [Pustaka Kasus SBU, SKK & Perizinan Usaha](https://app.notion.com/p/Pustaka-Kasus-SBU-SKK-Perizinan-Usaha-0269ad9eacd4455fa0d143192887ff70?pvs=21)), dan Modul LSBU.
- Koreksi kualifikasi: memakai K1, K2, K3, M, B (Permen PU 6/2025 & Kepdirjen Bina Konstruksi 281/2026) sebagai data master; Prompt 0, 2, 3, dan 19A sudah disesuaikan.
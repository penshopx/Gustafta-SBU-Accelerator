# Pustaka Kasus SBU, SKK & Perizinan Usaha

> 🧭 Pustaka studi banding SBU, SKK, dan perizinan usaha untuk kontraktor, konsultan, serta tenaga kerja konstruksi. Data awal berupa **skenario pembelajaran**, bukan rekaman kejadian nyata yang telah diverifikasi. Dipakai untuk fitur Pustaka Kasus, Tutor Regulasi, materi edukasi, dan persiapan konsultasi. Semua skenario awal berstatus **Draf**; rujukan dan solusi perlu telaah manusia sebelum publikasi.
> 

## Cara membaca

Pilih database **SBU / SKK / Perizinan Usaha**, lalu filter **Segmen**, **Jenis Permohonan**, dan **Tema**. Buka kasus untuk membaca **Gejala → Dugaan akar masalah → Diagnosis → Langkah penanganan → Bukti → Hasil yang diharapkan → Pelajaran studi banding → Rujukan dan batas penerapan**. Bandingkan konteks dan bukti, bukan hanya judul. Tabel A–C di bawah adalah 24 pola masalah awal yang belum memiliki bukti kejadian; gunakan tiga database pada bagian F sebagai pustaka terstruktur.

## A. Kontraktor (badan usaha pelaksana)

| Kode | Gejala | Akar masalah | Solusi | Modul | Rujukan (cek) |
| --- | --- | --- | --- | --- | --- |
| K-01 | SBU lama masih berlaku, bingung wajib apa di skema baru | Belum memahami ketentuan peralihan PP 28/2025 & Permen PU 6/2025 | 1) Cek masa berlaku SBU lama; 2) pilih jalur: penyesuaian / pemberlakuan operasional / konversi; 3) susun rencana sebelum tenggat | Verifikasi Transisi, Tutor (Mode Bandingkan) | Ketentuan peralihan PP 28/2025, Permen PU 6/2025, Kepdirjen terbaru |
| K-02 | Permohonan tertahan: KBLI tidak cocok subklasifikasi | KBLI di NIB tidak sesuai subklasifikasi yang diajukan | 1) Petakan subklasifikasi ↔ KBLI di Katalog; 2) ubah/tambah KBLI di OSS RBA; 3) baru ajukan SBU | Katalog, Kasus (perubahan data) | PP 28/2025 (perizinan berbasis risiko), lampiran KBLI |
| K-03 | Ingin naik kualifikasi (mis. K3 → M), ditolak | Penjualan tahunan/pengalaman tidak terbukti cukup | 1) Kumpulkan kontrak + BAST per tahun; 2) hitung sesuai cara hitung resmi; 3) bila kurang, tetap di kualifikasi sekarang + rencana bertahap | Kalkulator, Bukti | Permen PU 6/2025 (syarat kualifikasi) |
| K-04 | Kemampuan keuangan dinilai kurang | Laporan keuangan tidak memenuhi format/audit yang disyaratkan; ekuitas tidak tercatat benar | 1) Cek syarat laporan per kualifikasi; 2) audit KAP bila disyaratkan; 3) rapikan pencatatan modal sesuai standar akuntansi | Kalkulator (dimensi keuangan) | Permen PU 6/2025 |
| K-05 | PJTBU/PJSKBU tidak sesuai | SKK personel beda subklasifikasi atau jenjang terlalu rendah | 1) Petakan personel vs syarat; 2) personel ikut uji kompetensi di LSP yang sesuai; 3) atau rekrut tenaga tetap | Personel & SKK, Exum SKK | Permen PU 6/2025; ketentuan SKK |
| K-06 | Personel "pinjam nama" / tercatat di BU lain | Praktik rangkap PJ | 1) Gunakan tenaga tetap dengan kontrak kerja; 2) pastikan personel tidak terdaftar di BU lain; 3) simpan surat pernyataan | Personel (deteksi rangkap) | Larangan rangkap sesuai ketentuan — cek pasal |
| K-07 | Bukti peralatan ditolak | Tidak ada bukti kepemilikan/sewa yang sah | 1) Daftar alat sesuai syarat subklasifikasi; 2) lengkapi faktur/BPKB/kontrak sewa; 3) foto & spesifikasi | Bukti | Permen PU 6/2025 (bila disyaratkan) |
| K-08 | Diminta SMAP, belum punya | Kualifikasi tertentu mensyaratkan sistem manajemen anti penyuapan | 1) Surat komitmen; 2) bimtek; 3) penerapan & sertifikasi bila disyaratkan | Compliance Hub, Bukti (smap_smm) | Permen PU 6/2025 — cek tahapan berlakunya |
| K-09 | Mengajukan banyak subklasifikasi, sebagian gagal | Tenaga ahli & pengalaman tidak mendukung semua subklasifikasi | 1) Prioritaskan subklasifikasi yang terbukti; 2) tunda sisanya; 3) rencana penambahan subklasifikasi | Kalkulator per subklasifikasi | – |
| K-10 | SBU hampir habis saat ikut tender | Tidak ada kalender masa berlaku | 1) Ajukan perpanjangan jauh hari; 2) aktifkan pengingat 90/30/7 hari | Pengingat | Ketentuan masa berlaku SBU |
| K-11 | Data perusahaan tidak sinkron (pengurus, alamat, modal berubah) | Akta baru belum diperbarui di OSS/sistem | 1) Perbarui di AHU & OSS; 2) ajukan perubahan data SBU | Kasus (perubahan data), Ruang Simpan | – |
| K-12 | Tidak tahu harus ke LSBU mana dan apa saja yang dinilai | Kurang paham peran & alur LSBU | 1) Pilih LSBU yang berlisensi untuk jenis usaha; 2) siapkan Paket Siap Ajukan; 3) ikuti verifikasi LSBU | Modul LSBU, Paket Siap Ajukan | UU Jasa Konstruksi beserta perubahannya; PP 28/2025 |

## B. Konsultan (perencana / pengawas / manajemen konstruksi)

| Kode | Gejala | Akar masalah | Solusi | Modul | Rujukan (cek) |
| --- | --- | --- | --- | --- | --- |
| C-01 | Bingung subklasifikasi konsultansi vs KBLI | Katalog konsultansi berbeda dari pekerjaan konstruksi | Gunakan filter jenis usaha "konsultan" di Katalog, cocokkan KBLI | Katalog | PP 28/2025, Permen PU 6/2025 |
| C-02 | Tenaga ahli lepas (freelance) dipakai sebagai PJ | Status kepegawaian tidak memenuhi | Ikat PJ sebagai tenaga tetap; tenaga ahli lepas hanya untuk proyek | Personel | Ketentuan PJ — cek pasal |
| C-03 | Pengalaman dari KSO/subkonsultan tidak diakui penuh | Porsi pekerjaan tidak terdokumentasi | Simpan perjanjian KSO, porsi nilai, BAST atas nama BU | Bukti | Ketentuan pengalaman |
| C-04 | Tenaga ahli banyak, SKK beragam kedaluwarsa | Tidak ada daftar terpusat | Daftar personel + pengingat SKK + rencana SKPK | Personel, Pengingat | Ketentuan SKK & pengembangan keprofesian |
| C-05 | Kantor konsultan perizinan mengurus banyak klien, dokumen tercecer | Tidak ada ruang kerja per klien | Ruang kerja multi-klien, akses klien untuk unggah | Multi-klien | – |
| C-06 | Laporan keuangan konsultan kecil sederhana | Tidak sesuai format yang disyaratkan | Cek syarat per kualifikasi; susun neraca sesuai standar | Kalkulator | Permen PU 6/2025 |

## C. Tenaga kerja konstruksi (individu calon PJ / tenaga ahli / terampil)

| Kode | Gejala | Akar masalah | Solusi | Modul | Rujukan (cek) |
| --- | --- | --- | --- | --- | --- |
| T-01 | Pengalaman ada, tapi tidak bisa dibuktikan | Tidak ada surat referensi/kontrak | Susun portofolio: surat keterangan kerja, kontrak, foto, BAST | Exum SKK, Ruang Simpan | Persyaratan uji kompetensi |
| T-02 | Jenjang SKK tidak sesuai syarat PJ | Pendidikan/pengalaman belum cukup untuk jenjang target | Ambil jenjang yang memenuhi sekarang; rencana naik jenjang | Tutor, Exum SKK | Standar kompetensi kerja |
| T-03 | Tidak tahu LSP mana yang sesuai | Banyak LSP, skema berbeda | Cari LSP berlisensi untuk skema/subklasifikasi terkait | Tutor, Exum SKK | Ketentuan BNSP/LPJK |
| T-04 | SKK akan habis, pengembangan keprofesian belum tercatat | Tidak ada catatan pelatihan | Catat kegiatan, rencana pemenuhan sebelum perpanjangan | Pengingat | Ketentuan SKK |
| T-05 | Nama dipakai beberapa BU tanpa izin | Data personel disalahgunakan | Cek status penugasan, ajukan pencabutan, buat pernyataan | Personel (catatan risiko) | Larangan rangkap |
| T-06 | Bingung beda SKK (perorangan) dan SBU (badan usaha) | Konsep lembaga tertukar | SKK oleh LSP untuk individu; SBU melalui LSBU untuk badan usaha | Tutor (Mode Belajar) | UU Jasa Konstruksi |

## D. Peran lembaga (agar tidak tertukar)

| Lembaga | Untuk siapa | Peran utama |
| --- | --- | --- |
| **LSBU** – Lembaga Sertifikasi Badan Usaha | Badan usaha (kontraktor & konsultan) | Melaksanakan sertifikasi badan usaha: menerima permohonan, verifikasi & validasi dokumen, penilaian kesesuaian, dan penerbitan SBU sesuai mekanisme yang ditetapkan |
| **LSP** – Lembaga Sertifikasi Profesi | Tenaga kerja konstruksi | Uji kompetensi dan sertifikasi kompetensi kerja (SKK) |
| **Kementerian PU (Ditjen Bina Konstruksi)** | Semua | Regulator: menetapkan norma, standar, prosedur, kriteria; pembinaan & pengawasan |
| **LPJK** | Ekosistem | Fungsi yang diberikan regulasi (mis. pencatatan, akreditasi/lisensi tertentu) — cek ketentuan terbaru |
| **OSS RBA** | Badan usaha | Perizinan berusaha (NIB, KBLI) yang menjadi dasar SBU |
| **SBU Accelerator** | Pengguna | Alat bantu persiapan mandiri; tidak menggantikan peran lembaga di atas |

## E. Format data untuk aplikasi (seed JSONL)

Satu baris JSON untuk setiap kasus. Kode kasus menjadi kunci impor agar pengulangan impor tidak menambah duplikat. Modul: `SBU`, `SKK`, atau `PERIZINAN`. Isi awal tetap Draf dan belum otomatis terpasang di aplikasi.

```
kode, modul, segmen[], jenis_permohonan, tema, judul, gejala, dugaan_akar_masalah, diagnosis[], solusi_langkah[], bukti_persiapan[], peran_lembaga, hasil_diharapkan, hasil_aktual, pelajaran_studi_banding, rujukan[], batas_penerapan, asal_kasus, status_telaah
```

### Paket data awal untuk aplikasi

Paket unduhan memuat JSONL per modul dan gabungan 150 skenario, panduan impor/pencatatan kasus nyata, serta hasil pemeriksaan jumlah dan keunikan kode. Pilih **file gabungan atau tiga file per modul**; jangan mengimpor keduanya sebagai salinan berbeda. Semua entri tetap Draf. Paket ini belum diimpor ke aplikasi Replit.

[Pustaka_Kasus_SBU_Accelerator_150_Draf.zip](Pustaka_Kasus_SBU_Accelerator_150_Draf.zip)

## F. Database kasus per modul

Tiga pustaka masing-masing memuat **50 skenario awal**: **20 permohonan baru**, **15 perpanjangan/pemeriksaan keberlanjutan**, dan **15 perubahan data**. Total 150 skenario, terpisah dari 24 pola masalah awal pada tabel A–C. Tampilan tabel untuk pencarian lintas tema; tampilan papan untuk membandingkan jenis permohonan.

**Khusus perizinan:** kategori Perpanjangan juga mencakup pemeriksaan masa berlaku dan keberlanjutan izin, bukan kewajiban memperpanjang semua dokumen. NIB berlaku selama pelaku usaha menjalankan kegiatan usaha sesuai ketentuan; tidak diperlakukan sebagai izin tahunan. Rujukan: PP 28/2025 Pasal 206 ayat (9).[[1]](https://app.notion.com/p/01-Regulasi-Primer-dan-Standar-Skema-SBU-ae3d1474d2b648e7a66066e99322830a?pvs=21)

### Kendali mutu dan kasus nyata

- **Skenario studi banding:** contoh hipotetis, tidak boleh diberi nama klien, tanggal kejadian, atau hasil seolah-olah nyata.
- **Laporan kasus belum diverifikasi:** pengalaman yang diterima dari praktisi tetapi bukti dan hasilnya belum diperiksa. Tidak tampil sebagai kasus terverifikasi.
- **Kasus nyata bersumber:** memerlukan kronologi tersamar, izin penggunaan, bukti masalah, tindakan, hasil aktual, sumber, dan pemeriksa. Identitas pribadi, nomor lengkap dokumen, serta rahasia klien tidak dipublikasikan.
- **Draf → Ditelaah → Final:** promosi status hanya oleh penelaah berwenang. Publikasi pengguna hanya untuk Final; label asal kasus tetap terlihat. Perubahan regulasi/skema memicu telaah ulang, bukan mengubah rujukan otomatis.
- Checklist bukti merupakan panduan persiapan, bukan daftar syarat wajib universal. Keputusan SBU oleh LSBU, kompetensi oleh LSP sesuai skema, dan perizinan oleh pihak berwenang; aplikasi tidak menerbitkan atau menjamin kelulusan.
- Persyaratan SKK/PKB harus dicocokkan dengan skema dan aturan resmi yang relevan. Angka ambang, biaya, serta tenggat tidak diisi dari dugaan. Surat pemberlakuan operasional SIJK untuk pemicu konversi SBU belum terkonfirmasi dalam kumpulan sumber.

[Pustaka Kasus SBU](Pustaka%20Kasus%20SBU%20fce01c3bd439406d8c084081c9782de7.csv)

[Pustaka Kasus SKK](Pustaka%20Kasus%20SKK%2071579aa22af44f51b0933ab81b10c08b.csv)

[Pustaka Kasus Perizinan Usaha](Pustaka%20Kasus%20Perizinan%20Usaha%207e865f87c8964e39aca50c438710d1a4.csv)
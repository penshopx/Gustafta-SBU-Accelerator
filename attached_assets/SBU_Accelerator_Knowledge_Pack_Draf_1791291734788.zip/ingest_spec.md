# Integrasi ke SBU Accelerator

Ikuti fondasi yang sudah dirancang: reg_documents, reg_chunks, catalog_subclass,
requirements, requirement_history, reg_changes dan audit_logs.

1. Impor register dan teks ke area staging/draf, bukan tabel aturan aktif.
2. Unggah atau tautkan PDF asli ke storage privat aplikasi, cocokkan SHA-256,
   lalu petakan document_id dan file_ref. Jangan memakai session-file URI
   sebagai URL produksi atau endpoint publik.
3. Cocokkan identitas, status hukum dan hubungan perubahan/pencabutan dari
   sumber resmi. Lengkapi tanggal mulai operasional hanya dari surat yang sah.
4. Periksa halaman minim teks; lakukan OCR atau transkripsi visual, lalu telaah.
5. Pisahkan teks per pasal/ayat/lampiran dengan rujukan yang benar. Validasi
   locator halaman dan pasangan baris/kolom tabel.
6. Pisahkan sumber normatif, klasifikasi BPS, panduan operasional dan praktik
   lembaga. Sumber pendukung tidak boleh menjadi dasar norma mandiri.
7. Ekstraksi calon catalog_subclass/requirements selalu berstatus draf, dengan
   document_id, pasal/lampiran, halaman PDF, versi dan cakupan jenis usaha.
8. Penelaah menyetujui tiap pemetaan dan parameter. Hanya admin berwenang dapat
   mengubah status menjadi ditelaah/final atau menerbitkan korpus.
9. Evaluasi Tutor dengan uji sitasi, pertanyaan di luar korpus, konflik sumber,
   masa transisi, dan perbedaan kualifikasi berdasarkan jenis usaha.
10. Impor ini tidak menerbitkan SBU, tidak mengajukan ke OSS/SIJK/LSBU dan tidak
    menjamin hasil sertifikasi. Simpan riwayat perubahan dan persetujuan.

Gerbang khusus transisi:
- Permen PU 6/2025 Pasal 20 membedakan kesiapan SIJK dan surat dimulainya proses.
- Pasal 21 ayat (2) mengaitkan tenggat konversi dengan surat Pasal 20 ayat (2).
- Tanpa surat pemicu tersebut, tampilkan 'tanggal pemicu belum dikonfirmasi';
  jangan membuat tanggal jatuh tempo kalender dari tanggal Kepdirjen.

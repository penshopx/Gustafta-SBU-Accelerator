# SBU Accelerator — Knowledge Pack Draf

Paket ini menyiapkan dokumen terlampir sebagai bahan kurasi pengetahuan.
Ini BUKAN basis aturan final, hasil verifikasi resmi, atau impor ke aplikasi.

## Isi
- reg_documents.staging.jsonl: register sumber, identitas, peran dan provenance.
- reg_pages.staging.jsonl: teks native seluruh halaman PDF, termasuk halaman minim teks.
- reg_chunks.staging.jsonl: potongan kandidat untuk pencarian, dengan locator halaman.
- page_annotations.jsonl: pencocokan visual terbatas atas identitas/tanggal kritis.
- source_integrity_manifest.json: hash SHA-256 dokumen asli.
- extraction_quality.json: statistik ekstraksi dan masalah yang harus ditelaah.
- ingest_spec.md: batas integrasi dan gerbang persetujuan.

PDF asli tidak disertakan dalam arsip teks ini. Dokumen asli disimpan pada koleksi
sumber Notion. source_file_uri adalah referensi lampiran sesi, bukan URL storage
produksi: pemilik aplikasi harus mengunggah/menautkan dokumen ke storage aplikasi
dan memetakan file_ref sebelum mengaktifkan sitasi.

Semua dokumen/potongan berstatus draf dan belum terbit. Tidak ada embeddings,
requirements final, atau perubahan rules engine. Status hukum terkini tidak
disimpulkan hanya dari adanya PDF atau tanggal penetapan.

Potongan berbasis halaman PDF, belum dipisah dan disahkan per pasal/ayat/lampiran.
rujukan_kandidat_belum_divalidasi hanya petunjuk parser; bukan sitasi yang sah.
Baris dan kolom tabel harus ditelaah dari PDF sebelum diubah menjadi syarat.
Halaman gambar/minim teks tidak dianggap kosong secara substantif.

KBLI 2025: teks penuh diarsipkan pada reg_pages, tetapi kandidat chunks dibatasi
pada taksonomi, konversi, Kategori F dan aktivitas konsultansi terkait.
Materi penjualan dan aset logo dicatat dalam register tetapi dikecualikan dari RAG.

Kelengkapan korpus: teks mandiri UU Jasa Konstruksi beserta perubahannya,
PP 22/2020 jo. PP 14/2021, Permen PUPR 8/2022 dan surat pemicu operasional
SIJK belum tersedia dalam koleksi ini. Matriks lampiran PP 28/2025 belum
teridentifikasi dalam salinan yang diunggah. Jangan menganggap suatu
peraturan sudah tersedia hanya karena disebut dalam konsiderans sumber lain.

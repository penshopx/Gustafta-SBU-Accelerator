# Pustaka Kasus SBU Accelerator — seed 1.0

## Isi
150 skenario hipotetis: SBU 50, SKK 50, PERIZINAN 50. Setiap modul berisi 20 Baru, 15 Perpanjangan, 15 Perubahan data. Semua Draf; bukan 150 pengalaman nyata terverifikasi.

## Cara memakai
Pilih seed_semua_modul.jsonl ATAU tiga seed per modul, bukan keduanya sebagai salinan terpisah. Gunakan kode sebagai kunci unik/upsert. Nilai segmen dan status mempertahankan ejaan persis pada JSONL. Semua hasil_aktual dan sumber_kejadian kosong. Tidak ada angka peluang keberhasilan, identitas klien, atau kejadian buatan. File seed bukan bukti bahwa aplikasi Replit sudah diubah.

Kasus studi banding memuat dugaan akar, diagnosis, langkah, checklist bukti, peran, hasil yang diharapkan, pelajaran, rujukan, dan batas penerapan. Checklist persiapan bukan syarat wajib universal. Ketentuan SBU bergantung jenis/kualifikasi/bentuk BU; SKK/PKB membutuhkan skema/aturan resmi yang spesifik. Rujukan paparan/internal tidak menggantikan regulasi. Tingkat risiko/lingkungan memerlukan penapisan resmi. NIB bukan dokumen perpanjangan tahunan; PP 28/2025 Pasal 206 ayat (9). Tenggat konversi SBU tidak ditetapkan tanpa surat pemicu operasional SIJK.

## Menambahkan pengalaman nyata
1. Simpan sebagai Laporan kasus belum diverifikasi dan Draf.
2. Catat konteks, kronologi tersamar, jenis permohonan, sumber kejadian, masalah, dugaan penyebab, bukti, tindakan, serta hasil aktual (termasuk bila belum selesai).
3. Dapatkan izin penggunaan dan tentukan batas kerahasiaan. Bukti asli privat; publik hanya ringkasan/salinan anonim. Jangan menaruh sandi/OTP atau identitas lengkap dalam pustaka.
4. Penelaah memeriksa sumber, keaslian bukti, jalur lembaga, solusi, hasil, dan versi aturan. Baru setelah itu asal boleh menjadi Kasus nyata bersumber.
5. Publikasi aplikasi hanya setelah Final. Asal skenario atau kasus nyata tetap terlihat; hasil diharapkan tidak dilabeli hasil aktual.

## Kendali mutu
qa_local.json memeriksa jumlah, keunikan kode/judul, status, asal, dan cakupan permohonan. Hasil verifikasi Notion ditambahkan setelah impor. Perubahan aturan memerlukan telaah ulang manusia.

# 01 — Regulasi Primer dan Standar Skema SBU

Sumber utama untuk menelaah norma, persyaratan dan skema sertifikasi. Identitas kunci telah dicocokkan dari berkas; status hukum terkini, pemicu operasional dan aturan per kasus tetap memerlukan persetujuan penelaah.

**Status:** draf kurasi; tidak ada syarat yang diaktifkan dari halaman ini.

## SBU-SRC-001 — PP 28 Tahun 2025 — Penyelenggaraan Perizinan Berusaha Berbasis Risiko

**Berkas asli:** PP Nomor 28 Tahun 2025.pdf
**Peran sumber:** primer. **Cakupan:** Kerangka PBBR, kewenangan, peralihan dan penutup.
**Catatan:** Dasar normatif; status terkini tetap perlu pemeriksaan sebelum dipublikasikan.
**Jumlah halaman PDF:** 383.

[PP_Nomor_28_Tahun_2025.pdf](PP_Nomor_28_Tahun_2025.pdf)

## SBU-SRC-002 — Permen PU 6 Tahun 2025 — Standar Usaha, Pengawasan dan Sanksi

**Berkas asli:** permen-pu-6-2025.pdf
**Peran sumber:** primer. **Cakupan:** Standar jasa konstruksi, persyaratan, peralihan SBU, pengawasan dan sanksi.
**Catatan:** Pasal 20–21 memisahkan berlakunya peraturan dari dimulainya operasional sertifikasi melalui SIJK.
**Jumlah halaman PDF:** 393.
**Tanggal yang dicocokkan:** ditetapkan December 22, 2025; diundangkan December 30, 2025. Rujukan: Pasal 25 dan halaman PDF 16.

[permen-pu-6-2025.pdf](permen-pu-6-2025.pdf)

## SBU-SRC-003 — Kepdirjen Bina Konstruksi 281/KPTS/DK/2026 — Standar Skema Sertifikasi BUJK

**Berkas asli:** KEP_DIRJEN_BK_281_STANDAR_SKEMA_SERTIFIKASI_26_AGUSTUS_2026_SURAT_PENGANTAR.pdf
**Peran sumber:** primer. **Cakupan:** Pemetaan KBLI–subklasifikasi, jenis/sifat/kualifikasi usaha, persyaratan, proses dan lampiran.
**Catatan:** Surat pengantar, keputusan dan lampiran berada dalam satu PDF. Surat pengantar butir 2 mensyaratkan penyesuaian SIJK dan surat pemberlakuan operasional.
**Jumlah halaman PDF:** 186.
**Kualitas ekstraksi:** halaman berikut minim teks native dan perlu pemeriksaan gambar/OCR: 2, 3, 5, 186.
**Tanggal yang dicocokkan:** ditetapkan August 26, 2026. Rujukan identitas: halaman PDF 3 dan 5; syarat pemberlakuan operasional: surat pengantar, halaman PDF 1, butir 2.
**Bagian prioritas untuk ditelaah:** Lampiran 2.1.3 (kualifikasi), 2.1.5 (KBLI–subklasifikasi), persyaratan BUJK, proses sertifikasi dan lampiran bukti. Tanggal operasional belum dikonfirmasi dari surat pemicu.

[KEP_DIRJEN_BK_281_STANDAR_SKEMA_SERTIFIKASI_26_AGUSTUS_2026_SURAT_PENGANTAR.pdf](KEP_DIRJEN_BK_281_STANDAR_SKEMA_SERTIFIKASI_26_AGUSTUS_2026_SURAT_PENGANTAR.pdf)